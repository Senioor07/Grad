package com.example.part1v2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
