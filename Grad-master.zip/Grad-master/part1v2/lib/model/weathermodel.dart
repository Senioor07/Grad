class weather{
  var cittyname;
  var icon;
  var temp;
  var condition;
  var wind;
  var humdity;
  var wind_dir;
  var local_time;
  weather({
    this.cittyname,this.icon,this.temp,this.condition,this.humdity,this.wind,this.wind_dir,this.local_time
  });
  weather.fromjson(Map<String,dynamic>json){
    cittyname=json["location"]["name"];
    icon=json["current"]["condition"]["icon"];
    condition=json["current"]["condition"]["text"];
    temp=json["current"]["temp_c"];
    wind=json["current"]["wind_kph"];
    humdity=json["current"]["humidity"];
    wind_dir=json["current"]["wind_dir"];
    local_time=json["location"]["localtime"];
  }
}