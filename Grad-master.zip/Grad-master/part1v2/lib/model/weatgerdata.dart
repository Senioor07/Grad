import 'dart:convert';

import 'package:http/http.dart'as http;
import 'package:part1v2/model/weathermodel.dart';

class weatherdata{
  Future<weather>getData(var latitude,var longitude)async{
    var uricall=Uri.parse("http://api.weatherapi.com/v1/current.json?key=4da23ab412f047a4bff183841231010&q=$latitude,$longitude&aqi=no");
    var response=await  http.get(uricall);
    var body=jsonDecode(response.body);
    return weather.fromjson(body);
  }
}