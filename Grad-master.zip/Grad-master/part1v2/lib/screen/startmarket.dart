import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/screen/marketing.dart';

class startmarket extends StatefulWidget {
  const startmarket({super.key});

  @override
  State<startmarket> createState() => _startmarketState();
}

class _startmarketState extends State<startmarket> {
  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
     backgroundColor: Color.fromARGB(35, 4, 212, 15),
      body: Stack(
        children: [
          Positioned(
            bottom: 100.h,right: 10.w,
            child: IconButton(onPressed: (){},
             icon: Icon(Icons.arrow_forward_outlined)),
          ),
          Image.asset("assets/do.jpg",fit: BoxFit.fill,),
          Positioned(
            top: 300.h,left: 67.w,
            child: Text("Special Market",style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),)),
            Positioned(
              bottom: 60.h,right: 1.w,
              child:  ElevatedButton(
                          onPressed: () {
                             //Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>marketingpageScreen()));
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Color.fromARGB(159, 3, 92, 6),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              
                            ),
                              minimumSize: Size(100, 50), //width 
                           maximumSize: Size(100, double.infinity), 
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              
                             
                              const Text(
                                "Start",
                                style: TextStyle(color: Colors.white),
                              ),
                               const SizedBox(width: 5),
                               Icon(Icons.arrow_forward_ios_outlined, color: Colors.white),
                            ],
                          ),
                        ),
            )

        ],
      )

    );
  }
}