//import 'dart:js_util';

import 'package:flutter/material.dart';
import 'package:part1v2/screen/card.dart';
import 'package:part1v2/screen/fertllizersmarket.dart';

import 'package:part1v2/screen/plantmarket.dart';
import 'package:part1v2/screen/seedsmarket.dart';
import 'package:part1v2/screen/toolsmarket.dart';
import 'dart:async';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class Market extends StatefulWidget {
  
  const Market({super.key});

  @override
  State<Market> createState() => _MarketState();
  
}



class _MarketState extends State<Market> with TickerProviderStateMixin {
  late TabController tabController;
 
   PageController _pageController = PageController(initialPage: 0);

  int _currentPage = 0;
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 4, vsync: this);
    _startTimer();
  }
  

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  void _startTimer() {
    _timer = Timer.periodic(Duration(seconds: 5), (timer) {
      if (_currentPage < 2) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }
      _pageController.animateToPage(
        _currentPage,
        duration: Duration(milliseconds: 300),
        curve: Curves.easeIn,
      );
    });
  }
  @override
  
  Widget build(BuildContext context) {

 
    
    return Scaffold(
      body: 
      
        Container(
         // color: Color.fromRGBO(248, 225, 213, 1),
          child: Column(
            
            
            children : [
              
              Padding(
          padding: const EdgeInsets.only(right: 10,top: 30),
           child :Row(
                      mainAxisAlignment: MainAxisAlignment.end,
        
            children: [
               IconButton(
          icon: Icon(Icons.arrow_back),
          onPressed: () {}
            ),
             SizedBox(width: 255,),
               IconButton(
          icon: Icon(Icons.shopping_cart),
          onPressed: () {
         
         Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>cardpage()));
          }
            ),
             IconButton(
          icon: Icon(Icons.favorite),
          onPressed: () {}
            ),
            ],
            
            
          ),
              ),
             
                  
                  Container(
             
               padding: EdgeInsets.only(right: 10 ,left: 10),
            height: 130,
            
            
        child:  Stack(
          children: [
             PageView(
              
               controller: _pageController,
            onPageChanged: (int page) {
              setState(() {
                _currentPage = page;
              });
            },
            children: <Widget>[
              
              Container(
                decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.0),
                
             ),
             child: ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
               
                child: Image.asset('assets/pagee1.jpeg',fit: BoxFit.cover,)
             )
                
              ),
              Container(
                decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.0),
                
             ),
             child: ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
               
                child: Image.asset('assets/pagee2.jpg',fit: BoxFit.cover,)
             )
                
              ),
              Container(
                decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15.0),
                
             ),
             child: ClipRRect(
              borderRadius: BorderRadius.circular(15.0),
               
                child: Image.asset('assets/pagee3.png',fit: BoxFit.cover,)
             )   
              ),
              
              
            
            ],
            ),
            Positioned(
              top: 170,
              left: 160,
                      child: SmoothPageIndicator(
                        
                        controller: _pageController,
                        count: 3,
                        effect: WormEffect(
                          activeDotColor:
                              Color.fromARGB(255, 110, 37, 37),
                          dotColor: Colors.grey,
                        ),
                      ),
                    ),
          ],
        ),
          
            
            
          ),
          const SizedBox(height: 15,),
         Container(
          child: Padding(
            padding: const EdgeInsets.only(left:6.0,right: 6),
            child: TabBar(
              controller: tabController,
              
              indicatorColor:  Color.fromARGB(255, 160, 67, 67), 
              tabs: [
              Text('plant',style: TextStyle(
               color : Color.fromARGB(255, 110, 37, 37),
               fontSize: 20
                ,)
                )
                ,
              Text('Seeds',style: TextStyle(
               color : Color.fromARGB(255, 110, 37, 37),
               fontSize: 20
                ,)),
              Text('Fertllizers',style: TextStyle(
               color : Color.fromARGB(255, 110, 37, 37),
               fontSize: 15
                ,)),
              Text('Tools',style: TextStyle(
               color : Color.fromARGB(255, 110, 37, 37),
               fontSize: 20
                ,)),
                
             
            ]
            
            
            ),
          ),
          
        ),
            Container(
              width: double.maxFinite,
              height: 365,
             child: TabBarView(
              controller: tabController,
              children: [
          plantmarket(),
          seedsmarket(),
          fertllizersmarket(),
          toolsmarket()

          
        ])

            )
      
          
          ]
          
                
              ),
              
        
            
              ),
              
        ) 
     ;
  }
}