import 'dart:io';
import 'package:image_picker/image_picker.dart';
import 'package:flutter/material.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/Vendor_products.dart';

class Edit_product extends StatefulWidget {
  const Edit_product({super.key,required this.plantidmarket});
  final int plantidmarket;

  @override
  State<Edit_product> createState() => _Edit_productState();
  
}

class _Edit_productState extends State<Edit_product> {
   List<Plant> _plantmarketlist=Plant.plantList;
  File? _image;
    String? _selectedItem;
    
    Future getImage() async {
    final picker = ImagePicker();

   final pickedFile = await picker.getImage(source: ImageSource.gallery);
    

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
      
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      body: Column(
        children: [
           Expanded(
          flex: 2,
          child: GestureDetector(
            onTap: () {
              getImage();
            },
            child: Container(
              padding: EdgeInsets.only(top: 20),
              
              color: Colors.grey[300],
              width: 300,
              child: _image == null
                  ?  Image.asset(_plantmarketlist[widget.plantidmarket].imageURL2)
                  : FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: MediaQuery.of(context).size.width,
                        height: MediaQuery.of(context).size.height * 0.6,
                        child: Image.file(_image!),
                      ),
                    ),
            ),
          ),
        ),
         Padding(
          padding: const EdgeInsets.all(20.0),
          child: Row(
            children: [
              Expanded(
                child: Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: TextField(
                   
                    decoration: InputDecoration(
                      hintText: "${_plantmarketlist[widget.plantidmarket].plantName2}",
                      border: OutlineInputBorder(),
                    ),
                  ),
                ),
              ),
              SizedBox(width: 20.0),
              SizedBox(
                width: 100,
                child: Row(
                  children: [
                    Flexible(
                      child: TextField(
                       
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                          hintText: "${_plantmarketlist[widget.plantidmarket].price}",
                          border: OutlineInputBorder(),
                        ),
                      ),
                    ),
                    Text('\$',style: TextStyle(fontSize: 30),),
                  ],
                ),
              ),
            ],
          ),
        ),
         Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextField(
            maxLines: 4,
            decoration: InputDecoration(
              hintText: '${_plantmarketlist[widget.plantidmarket].decription2}',
              border: OutlineInputBorder(),
            ),
          ),
        ),
         Padding(
          padding: const EdgeInsets.all(8.0),
          child: DropdownButtonFormField<String>(
            value: _selectedItem,
            items: [
              DropdownMenuItem(
                value: 'Plant',
                child: Text('Plant'),
              ),
              DropdownMenuItem(
                value: 'Seeds',
                child: Text('Seeds'),
              ),
              DropdownMenuItem(
                value: 'Fertillzers',
                child: Text('Fertillzers'),
              ),
              DropdownMenuItem(
                value: 'Tools',
                child: Text('Tools'),
              ),
            ],
            onChanged: (value) {
              setState(() {
                _selectedItem = value;
              });
            },
            decoration: InputDecoration(
              labelText: 'Select The type of product',
              border: OutlineInputBorder(),
            ),
          ),
        ),
         
        
           Container(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: ElevatedButton(
                   style: ElevatedButton.styleFrom(
    primary: Colors.green, 
  ),
                  
                  onPressed: () {
                     Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Vendor_product()));
                    print('Product added!');
                  },
                  child: Text('Add Product'),
                ),
              ),
            ),
          ),
       
        ],        
      ),
      
    );
  }
}