import 'dart:io';
import 'package:camera/camera.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:animated_bottom_navigation_bar/animated_bottom_navigation_bar.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:part1v2/screen/Camera_page.dart';

import 'package:part1v2/screen/homeScreen.dart';
import 'package:part1v2/screen/marketScreen.dart';
import 'package:part1v2/screen/marketing.dart';

import 'package:part1v2/screen/plant_view.dart';

import 'package:part1v2/screen/scanScreen.dart';
import 'package:part1v2/screen/searchScreen.dart';
import 'package:part1v2/screen/settingScreen.dart';
import 'package:part1v2/screen/weatherscreen.dart';


class homePage extends StatefulWidget {
  const homePage({super.key});

  @override
  State<homePage> createState() => _homePageState();
}

class _homePageState extends State<homePage> {

  int _bottomnavigationindex=0;

  ///list pages
  List<Widget> pages=[
    homeScreenpage(),
    searchScreenPage(),
    weatherScreenpage(),
    marketScreenpage(),
    
  ];
 // list iconpages
  List<IconData> iconlist=[
    Icons.home,
    Icons.search,
    Icons.sunny_snowing,
    Icons.shopping_cart,
    
   
  ];

  List<String> titlelist=[
   "Home",
   "Search",
   "Weather"
   "Market",
   
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     
      body: IndexedStack(
        index: _bottomnavigationindex,
        children:pages,
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: ()async {
            final image = await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => TakePictureScreen()),
            );
            if (image != null) {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => plant_view(image: image)),
              );
            }
          },
        child: 
        // IconButton(onPressed: (){},
        //  icon:Icon(Icons.document_scanner_rounded,size: 25,))
         Image.asset('assets/code-scan.png',height: 30,color: Color.fromARGB(255, 242, 240, 240),),
         //splashColor: Colors.black54,
         //inactive Color.fromRGBO(155, 202, 128, 1)
        backgroundColor: const Color.fromARGB(255, 37, 110, 66),
        ),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
        bottomNavigationBar: AnimatedBottomNavigationBar(
          backgroundColor: Color.fromRGBO(255, 255, 255, 1),//Color.fromRGBO(122, 61, 59, 1),
          icons: iconlist,iconSize: 40,
          activeIndex: _bottomnavigationindex,
          splashColor: const Color.fromARGB(255, 17, 184, 23),
          activeColor: Color.fromARGB(255, 17, 125, 41),
          inactiveColor: Color.fromARGB(255, 110, 37, 37),
          gapLocation: GapLocation.center,
          notchSmoothness: NotchSmoothness.softEdge,
            onTap: (index){
              setState(() {
                _bottomnavigationindex=index;
              });
            }),
      
    );
  }
   
}