import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/marketing.dart';

class favouritepage extends StatefulWidget {
  const favouritepage({super.key});

  @override
  State<favouritepage> createState() => _favouritepageState();
}

class _favouritepageState extends State<favouritepage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/k7.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
           
            Column(
          children: [
            SizedBox(height: 40.h,),
            
            Row(children: [
            IconButton(onPressed: (){
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
            }, icon:Icon(Icons.arrow_back)),
            SizedBox(width: 30.w,),
            Text ("My Favourites",style: TextStyle(fontSize: 28),)
            ],),
            SizedBox(height: 20.h,),
            Stack(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 7.h, horizontal: 15.w),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.only(topRight: Radius.circular(20),
                   bottomRight: Radius.circular(20)),
                   color: Color.fromRGBO(229, 242, 195, 1),
                  ),
                  width: 380.w,
                 height: 80.h,
                 child: Row(
        
                  children: [
                     Container(
                                    width: 80.w,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                    ),
                                    child: Image.asset("assets/pro10.png")),
                                     Padding(
                                    padding: const EdgeInsets.only(top:40,left: 40),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
        
                                     Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                       children: [
                                         Text(
                                          "Alovera",
                                          style: TextStyle(color: Color.fromARGB(255, 181, 77, 77), fontSize: 20),
        
                                    ),
                                    SizedBox(width: 68.w,),
                                     Text("80\$",
                                      style: TextStyle(
                                              color: Color.fromARGB(255, 181, 77, 77), fontSize: 18, fontWeight: FontWeight.bold),
                                    
                                    ),
                
                                       ],    )
                  ],
                 ),
                                     
                )
              ],
            )
                )]),
                SizedBox(height: 0.h,),
                Stack(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 7.h, horizontal: 15.w),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.only(topRight: Radius.circular(20),
                   bottomRight: Radius.circular(20)),
                   color: Color.fromRGBO(229, 242, 195, 1),
                  ),
                  width: 380.w,
                 height: 80.h,
                 child: Row(
        
                  children: [
                     Container(
                                    width: 80.w,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                    ),
                                    child: Image.asset("assets/indoor2.jpg",fit: BoxFit.fill,)),
                                     Padding(
                                    padding:  EdgeInsets.only(top:40.h,left: 40.w),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
        
                                     Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                                       children: [
                                         Text(
                                          "flower",
                                          style: TextStyle(color: Color.fromARGB(255, 181, 77, 77), fontSize: 20),
        
                                    ),
                                    SizedBox(width: 80.w,),
                                     Text("50\$",
                                      style: TextStyle(
                                              color: Color.fromARGB(255, 181, 77, 77), fontSize: 18, fontWeight: FontWeight.bold),
                                    
                                    ),
                
                                       ],    )
                  ],
                 ),
                                     
                )
              ],
            )
                )]),
        
                SizedBox(height: 100.h,),
           
          ],
        ),
          ],
        ),
      )
    );
  }
}