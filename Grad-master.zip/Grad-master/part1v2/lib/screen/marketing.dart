import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/constant/global_var.dart';
import 'package:part1v2/screen/Vendor_products.dart';
import 'package:part1v2/screen/card.dart';
import 'package:part1v2/screen/drawer.dart';
import 'package:part1v2/screen/favourite.dart';
import 'package:part1v2/screen/fertllizersmarket.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/plantmarket.dart';
import 'package:part1v2/screen/seedsmarket.dart';
import 'package:part1v2/screen/toolsmarket.dart';

class marketScreenpage extends StatefulWidget {
  const marketScreenpage({super.key});

  @override
  State<marketScreenpage> createState() => _marketScreenpageState();
}

class _marketScreenpageState extends State<marketScreenpage> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 4,
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 50,
          backgroundColor: Colors.white,
          title: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
                Visibility(
            visible: isChecked,
               child :Padding(
                 padding:  EdgeInsets.only(top: 17.h,right: 5.w),
                 child: IconButton(onPressed: (){
                    Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Vendor_product()));
                 },
                  icon: Icon(Icons.sell_outlined,size: 30,color: Colors.black,)),
               ),
                ),
               SizedBox(width:120.w,),
              Padding(
                padding: const EdgeInsets.only(top: 17,right: 5),
                child: Badge(
                  label: Text('1'),
                  child: IconButton(onPressed: (){
                 Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>cardpage()));
                  },
                   icon: Icon(Icons.add_shopping_cart,size: 30,color: Colors.black,)),
                ),
              ),
            Padding(
              padding: const EdgeInsets.only(right: 5,top: 17),
              child: IconButton(onPressed: (){
                 Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>favouritepage()));
              },
               icon: Icon(Icons.favorite,size: 30,color: Colors.black,)),
            ),
           
        
            ],
          ),
          bottom: TabBar(
            indicatorColor: const Color.fromARGB(255, 43, 100, 45),
            
            //indicator: circletabindicator(color: Color.fromARGB(255, 110, 37, 37), radius: 4),
            indicatorSize:TabBarIndicatorSize.label,
            labelColor: const Color.fromARGB(255, 49, 46, 46),
            tabs: [
          Tab(text: "plant", icon: Icon(Icons.auto_awesome_sharp,color:const Color.fromARGB(255, 35, 87, 36) ,),),
            Tab(text: "Seeds",icon: Icon(Icons.grain_rounded,color:const Color.fromARGB(255, 35, 87, 36)),),
              Tab(text: "Fertilizers",icon: Icon(Icons.vaccines_rounded,color:const Color.fromARGB(255, 35, 87, 36)),),
                Tab(text: "Tools",icon: Icon(Icons.agriculture,color:const Color.fromARGB(255, 35, 87, 36)),),
         ] ),
        
         
         
        ),
      //  drawer: mydrawer(),
        body: TabBarView(children:[
          plantmarket(),
          seedsmarket(),
          fertllizersmarket(),
          toolsmarket(),
        
        ]),
      ),
    );
  }

  
}
class circletabindicator extends Decoration{
  final Color color;
  final double radius;

  circletabindicator({required this.color,required this.radius});
  @override
  BoxPainter createBoxPainter([VoidCallback? onChanged]) {
    return _circlepainter(color, radius: radius);
  }

}

class _circlepainter extends BoxPainter{
  final double radius;
  final Color color;

  _circlepainter(this.color, {required this.radius});
  
  @override
  void paint(Canvas canvas, Offset offset, ImageConfiguration cfn) {
    Paint _paint;
    _paint=Paint()..color=color;
    _paint=_paint..isAntiAlias=true;
    final Offset circleoffset=
    offset+Offset(cfn.size!.width/2, cfn.size!.height-radius);
    canvas.drawCircle(circleoffset, radius, _paint);
    // TODO: implement paint
  }
 

}