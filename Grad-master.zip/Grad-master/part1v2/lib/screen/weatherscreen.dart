import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:part1v2/constant/weatherclass.dart';
import 'package:part1v2/model/weatgerdata.dart';

class weatherScreenpage extends StatefulWidget {
  const weatherScreenpage({Key? key}) : super(key: key);

  @override
  State<weatherScreenpage> createState() => _weatherScreenpageState();
}
var dayinfo=DateTime.now();
  var dateformat=DateFormat('EEEE,d MMM,yyy').format(dayinfo);
class _weatherScreenpageState extends State<weatherScreenpage> {
  var clien=weatherdata();
  var dat;

  info()async{
   // var position=await GetPosition();
    dat=await clien.getData('30.05', '31.25');
    return dat;

  }
  List<WE>_Weatherlist=WE.WetList;
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Scaffold(
      body: FutureBuilder(
          future:info() ,
          builder: (context, snapshot) {
            return SingleChildScrollView(
              child: Column(
                children: [
                  Stack(
                    children: [
                       Container(
                    height: 230.h,width: double.infinity,
                    decoration: BoxDecoration(
                    image: DecorationImage(image:AssetImage('assets/pool.jpg'),
                    fit: BoxFit.cover),
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(50),
                      bottomRight: Radius.circular(50),
                    )
                  ),
                  child: Padding(
                    padding:  EdgeInsets.only(top:50.h,right: 30.w,left: 30.w),
                    child: Column(
                      children: [
                       
                        Text("${dat?.cittyname}",
                        style:TextStyle(fontSize: 40, fontWeight: FontWeight.bold ,)),  
                      ],
                    ),
                  ),
                  
                  )
                  ,
                   Positioned(
                            top: 110.h,left: 180.w,
                            child: Text("${dat?.temp} ºC",style:TextStyle(fontSize: 38, fontWeight: FontWeight.w500 ,))),
                      
                  Positioned(
                    top: 100.h,left: 120.w,
                    child: Image.asset("assets/cp.png",scale: 9,),),
                    Positioned(
                    top: 160.h,left: 170.w,
                    child:  Text("${dat?.condition}",style:TextStyle(fontSize: 24, fontWeight: FontWeight.w500 ,)),),
                  Positioned(
                    top: 190.h,left: 125.w,
                    child: Text(dateformat,style:TextStyle(fontSize: 20, fontWeight: FontWeight.w500 ,)),),
                
            
            
                    ],
                  ),
                  SizedBox(height: 10.h,),
                    //  Stack(
                    //   children: [
                    //     Positioned(
                    // top: 250,left: 55,
                    // child: Text("Hourly",style:TextStyle(fontSize: 20, fontWeight: FontWeight.w500 ,)),),
                    //   ],
                    //  )
                    Container(
                      height: 550.h,////////this
                      color: Color.fromARGB(255, 255, 254, 254),
                      child: Column(
                        children: [      
                 Text("Hourly",style:TextStyle(fontSize: 20, fontWeight: FontWeight.w500 ,),
                  ),
                   SizedBox(height: 10.h,),
                  SizedBox(
                    height: 100.h,
                    
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      itemCount: _Weatherlist.length,
                      itemBuilder: (BuildContext context,int index) {
                        return Container(
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 245, 245, 238),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          width: 60.w,
                          margin: EdgeInsets.symmetric(horizontal: 10.h),
                          child: Stack(
                            children: [
                             Positioned(
                              top: 5.h,left: 13.w,
                              child:Image.asset(_Weatherlist[index].imagehour,scale: 17,),
                              ),
                              Positioned(
                              top: 45.h,left: 13.w,
                              child:Text(_Weatherlist[index].temhour,),
                              ),
                               Positioned(
                              top: 70.h,left: 13.w,
                              child:Text(_Weatherlist[index].hour,),
                              )
                            ],
                          ),
                        );
                        
                      },),
                  ),
                  Container(
                    padding:EdgeInsets.only(top: 20.h,left: 10.w),
                    child: Text("Daily",style:TextStyle(fontSize: 20, fontWeight: FontWeight.w500 ,)),
                  )
                  ,
                  SingleChildScrollView(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 12.w),
                      height: size.height*.5,
                      child: ListView.builder
                      (itemCount: _Weatherlist.length,
                        scrollDirection: Axis.vertical,
                        physics: BouncingScrollPhysics(),
                        itemBuilder: (BuildContext context,int index) {
                        return Container(
                          decoration: BoxDecoration(
                            color: Color.fromARGB(255, 245, 245, 238),
                            borderRadius: BorderRadius.circular(20)
                          ),
                          height: 75.h,width: 200.w,
                          padding: EdgeInsets.only(left:5.w ,top: 10.h),
                          margin: EdgeInsets.only(bottom: 10.w,top: 10.h),
                          child: Row(
                            children: [
                               Container(
                                  width: 80.w,
                                  decoration: BoxDecoration(
                                   // color: Colors.white
                                  ),
                                  child: Text(_Weatherlist[index].day,style: TextStyle(
                                    color: Colors.black,fontSize: 15
                                  ),),),
                                  SizedBox(width: 1.w,),
                                   Padding(
                                  padding:  EdgeInsets.only(top:1.h,left: 20.w),
                                  child: 
                                     Image.asset(_Weatherlist[index].imageday,scale: 17),
                                    
                                  ),
                                  SizedBox(width: 1.w,),
                                  Text(_Weatherlist[index].temday
                                    ,
                                    style: TextStyle(color: Colors.black),
                                  ),
                                  SizedBox(width: 20.w,),
                                  Text(_Weatherlist[index].describ
                                    ,
                                    style: TextStyle(color: Colors.black),
                                  ),
                                
                            ],
                          ),
                        );
                  
                      },),
                    ),
                  )
                   

                        ],
                      ),
                    )
            
                ],
              
                      ),
            );
        
          },
        
      ),
    );
  }
}