import 'package:flutter/material.dart';
import 'package:part1v2/screen/forget.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/register.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({Key? key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool pass = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            "assets/image1.jpg",
            height: 600,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.only(top: 220),
              decoration: BoxDecoration(
                color: Color.fromRGBO(248, 225, 213, 1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(40),
                  topRight: Radius.circular(40),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(30.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    const Text(
                      "Log In To Your Account",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 22,
                        height: 1.5,
                      ),
                    ),
                    const SizedBox(height: 20),
                    Column(
                      children: [
                        TextField(
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[300],
                            hintText: "User Name",
                            prefixIcon: Icon(
                              Icons.person,
                              color: Color.fromARGB(128, 3, 92, 6),
                            ),
                            border: OutlineInputBorder(
                              
                              borderRadius: BorderRadius.only(
                       bottomLeft: Radius.circular(16),topRight: Radius.circular(16)
                             ),

                          ),
                          ),
                        ),
                        const SizedBox(height: 25),
                        TextField(
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Colors.grey[300],
                            hintText: "Password",
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Color.fromARGB(128, 3, 92, 6),
                            ),
                            border: OutlineInputBorder(
                              
                              borderRadius: BorderRadius.only(
                       bottomLeft: Radius.circular(16),topRight: Radius.circular(16)
                             ),

                          ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                pass ? Icons.visibility_off : Icons.visibility,
                                color: Color.fromARGB(255, 8, 12, 9),
                              ),
                              onPressed: () {
                                setState(() {
                                  pass = !pass;
                                });
                              },
                            ),
                          ),
                          obscureText: pass,
                        ),
                        //const SizedBox(height: 10),
                        Padding(
                          padding: const EdgeInsets.only(left:210),
                          child: TextButton(
                            onPressed: () {
                              showModalBottomSheet(context: context,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                               builder:(context)=>Container(
                                padding: EdgeInsets.all(30),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Make selection!",style: Theme.of(context).textTheme.headline4,),

                                    Text("select one of the options given below to reset your password.",style: Theme.of(context).textTheme.bodyText2),
                                    SizedBox(height: 20,),
                                    forgetpasswordwidget(
                                      iconbtn: Icons.mail_outline_rounded,
                                       title: 'E-Mail', 
                                       subtitle: "Reset via E-Mail verification",
                                        ontap: () { 
                                           Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>forgetpasswordpage()));
                                         },),
                                    SizedBox(height: 10,),
                                    forgetpasswordwidget(
                                      title: "Phone-No",
                                       iconbtn: Icons.mobile_friendly_rounded, 
                                       subtitle: 'Reset via Phone verification',
                                        ontap: () {  },
                                    )
                                    
                                  ],
                                ),
                               ));
                              
                            },
                            child: const Text(
                              "Forgot Password?",
                              style: TextStyle(
                                color: Color.fromARGB(255, 183, 54, 48),
                              ),
                            ),
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () {
                             Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
                          },
                          style: ElevatedButton.styleFrom(
                            primary: Color.fromARGB(159, 3, 92, 6),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              
                            ),
                              minimumSize: Size(100, 50), //width 
                           maximumSize: Size(200, double.infinity), 
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.login, color: Colors.white),
                              const SizedBox(width: 5),
                              const Text(
                                "Log In",
                                style: TextStyle(color: Colors.white),
                              ),
                            ],
                          ),
                        ),
                         Row(
                          children: [
                            TextButton(
                              onPressed: () {},
                              child: const Text(
                                "Dont have an account?",
                                style: TextStyle(
                                  fontSize: 19,
                                  decoration: TextDecoration.underline,decorationColor: Color.fromARGB(159, 3, 92, 6),
                                  color: Color.fromARGB(255, 15, 20, 15),
                                ),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>registerScreen()));
                              },
                              child: const Text(
                                "Sign Up",
                                style: TextStyle(
                                  fontSize: 19,
                                  
                                  color: Color.fromARGB(159, 3, 92, 6)
                                ),
                              ),
                            ),
                          ],
                        ),
                         const SizedBox(height: 5),
                        Row(
                          children: [
                             Expanded(child: Divider(
                              color: Colors.black)),
                              Padding(
                              padding: EdgeInsets.symmetric(horizontal: 8.0),
                               child: Text('Continue With',style: TextStyle(
 color: Color.fromARGB(255, 13, 11, 11),
                            fontSize: 18,
                          ), 
                               ),
                                            ),
                            Expanded(child: Divider(color: Colors.black)),
                          ],
                        ),

                        
                        const SizedBox(height: 15),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                              GestureDetector(
                                onTap: () {
                                  
                                },
                                child: Image.asset("assets/fk.png",scale: 23,)),
                            // IconButton(
                            //   onPressed: () {},
                            //   icon: Icon(Icons.facebook, color: Colors.blue),
                            // ),
                            const SizedBox(width: 20),
                            Image.asset("assets/search.png",scale: 23,)
                            // IconButton(
                            //   onPressed: () {},
                            //   icon: Icon(Icons.g_translate, color: Colors.red),
                            // ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class forgetpasswordwidget extends StatelessWidget {
  const forgetpasswordwidget({
    super.key, required this.iconbtn, required this.title, required this.subtitle, required this.ontap,
  });
  final IconData iconbtn;
  final String title,subtitle;
  final VoidCallback ontap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: ontap,
      child: Container(
        padding: EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10),
          color: Colors.grey.shade200
        ),
        child: Row(
          children: [
            Icon(iconbtn,size: 50,),
            SizedBox(width: 10,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
              Text(title,style: Theme.of(context).textTheme.headline5,),
              Text(subtitle,style: Theme.of(context).textTheme.bodyText2,),
            ],)
          ],
        ),
      ),
    );
  }
}