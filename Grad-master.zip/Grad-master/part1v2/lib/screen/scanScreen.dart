import 'package:flutter/material.dart';

class scanScreenpage extends StatefulWidget {
  const scanScreenpage({super.key});

  @override
  State<scanScreenpage> createState() => _scanScreenpageState();
}

class _scanScreenpageState extends State<scanScreenpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Scan Screen'),
      ),
    );
  }
}