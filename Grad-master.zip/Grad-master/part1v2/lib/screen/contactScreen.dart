import 'package:flutter/material.dart';
import 'package:part1v2/screen/drawer.dart';

class contactScreenPage extends StatefulWidget {
  const contactScreenPage({super.key});

  @override
  State<contactScreenPage> createState() => _contactScreenPageState();
}

class _contactScreenPageState extends State<contactScreenPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Stack(
          children: [
             Image.asset("assets/ct.jpg",height: 280,width: double.infinity,scale: 1,),
             Container(
                margin: EdgeInsets.only(top: 235),
                
              //  height: 270,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 124, 56, 45),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(40),
                    topRight: Radius.circular(40),
                  )
                ),
                child: Padding(
                  padding: const EdgeInsets.only(top:25.0,left: 45.0,right: 45.0,bottom: 45.0),
                  child: Column(
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(left:13.0),
                        child: Text("We are here to help!"
                        ' send us your query via the form below'
                        "to any issue you are facing",style:
                         TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Colors.white),),
                      ),
                        SizedBox(height: 15,),
                      TextField(
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color.fromARGB(255, 239, 234, 234),
                                  hintText: "User Name",hintStyle: TextStyle(color: Color.fromARGB(255, 1, 4, 1)),
                                  prefixIcon: Icon(
                                    Icons.person,
                                    color: Color.fromRGBO(122, 61, 59, 1)
                                  ),
                                  border: OutlineInputBorder(
                                    
                                    borderRadius: BorderRadius.circular(20),
                
                                ),
                                
                                
                                ) 
                              ),
                               const SizedBox(height:10),
                         
                         
                             
                              TextField(
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color.fromARGB(255, 239, 234, 234),
                                  hintText: "Email",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                                  prefixIcon: Icon(
                                    Icons.email,
                                    color: Color.fromRGBO(122, 61, 59, 1),
                                  ),
                                    border: OutlineInputBorder(
                                    
                                     borderRadius: BorderRadius.circular(20),
                
                                ),
                                ),
                              ),
                              const SizedBox(height:10),
                         
                         
                             
                              TextField(
                                maxLines: 5,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color.fromARGB(255, 239, 234, 234),
                                  hintText: "Message",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                                  
                                  prefixIcon: Icon(
      
                                    Icons.message_rounded,
                                    color: Color.fromRGBO(122, 61, 59, 1),
                                  ),
                                    border: OutlineInputBorder(
                                    
                                     borderRadius: BorderRadius.circular(20),
                
                                ),
                                ),
                              ),
                              const SizedBox(height:10),
                         
                         
                             
                               ElevatedButton(
                            onPressed: () {
                              // Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Color.fromARGB(255, 231, 237, 231),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                
                              ),
                                minimumSize: Size(100, 50), //width 
                             maximumSize: Size(200, double.infinity), 
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(Icons.login, color: Color.fromRGBO(122, 61, 59, 1)),
                                const SizedBox(width: 5),
                                const Text(
                                  "Submit",
                                  style: TextStyle(color: Colors.black),
                                ),
                              ],
                            ),
                          ),
                         // SizedBox(height: 30,)
                              
                    ],
                  ),
                ),
                
              ),
              Positioned(
                top: 35,
                child: IconButton(onPressed: (){
                   Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>mydrawer()));
                },
                 icon: Icon(Icons.arrow_back)))
              
            
          ],
        ),
      ),
    );
  }
}