import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl/intl.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/generated/l10n.dart';
import 'package:part1v2/main.dart';
import 'package:part1v2/model/weatgerdata.dart';
import 'package:part1v2/screen/Gadgets.dart';
import 'package:part1v2/screen/drawer.dart';
import 'package:part1v2/screen/myPlantsScreen.dart';
  var dayinfo=DateTime.now();
  var dateformat=DateFormat('EEEE,d MMM,yyy').format(dayinfo);
class homeScreenpage extends StatefulWidget {
 

  @override
  State<homeScreenpage> createState() => _homeScreenpageState();
}
////green       Color.fromARGB(255, 37, 110, 66)
class _homeScreenpageState extends State<homeScreenpage> {
  var client=weatherdata();
  var data;

  info()async{
   // var position=await GetPosition();
    data=await client.getData('30.05', '31.25');
    return data;

  }
  
  @override
  Widget build(BuildContext context) {
    List<Plant> myplanted=[];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromRGBO(204, 203, 200, 1).withOpacity(.4),
        iconTheme: const IconThemeData(color: Color.fromARGB(255, 110, 37, 37)),
        elevation: 0.0,
       // actions: [Icon(Icons.add_alert_rounded,size: 40,)],
        
      ),
      
      drawer: const mydrawer(
        
      ),
      body: FutureBuilder(
        future: info(),
         builder:(context, snapshot) {
           return Stack(children: [
         Container(
        height: 220.h,
        decoration: const BoxDecoration(
                  image: DecorationImage(image:AssetImage('assets/k4.jpg'),
                  fit: BoxFit.cover),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(25),
                    bottomRight: Radius.circular(25),
                  )
                ),),
                Container(
                  margin:  EdgeInsets.only(left: is_Arabic()?0:20,top: 15,right:is_Arabic()?30:20),
                   width: 355.w,
                   height: 250.h,
                  decoration: BoxDecoration(
                    borderRadius: const BorderRadius.only(
                    bottomLeft: Radius.circular(25),
                    bottomRight: Radius.circular(25),
                    topLeft: Radius.circular(25),
                    topRight: Radius.circular(25)
                    
                  ),
                 
                    gradient: LinearGradient(
                      colors:[
                        const Color.fromRGBO(204, 203, 200, 1).withOpacity(.6),
                        
                        const Color.fromRGBO(226, 224, 218, 1).withOpacity(.6),

                      ])
                  ),
                  ////show  weather
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                     
                      Text("${data?.cittyname}",style: TextStyle(fontSize: 27.sp, fontWeight: FontWeight.bold ,)),
                       SizedBox(height: 5.h,),
                    //  Text("${data?.local_time}",style:TextStyle(fontSize: 20, fontWeight: FontWeight.w500 ,)),
                       Text(dateformat,style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w500 ,)),
                       SizedBox(height: 7.h,),
            
                          Text("${data?.temp} ºC",style: TextStyle(fontSize: 28.sp, fontWeight: FontWeight.w500 ,)),
                          // SizedBox(height: 8.h,),
                        //  Image.asset("assets/weather5.png",scale: 9,),
                           SizedBox(height: 8.h,),
                          Text("${data?.condition}",style: TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w500 ,)),

                       SizedBox(height: 0.h,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                         SizedBox(width: 14.w,),
                        Column(
                          children: [
                            
                            Image.asset("assets/rainny.png",scale: 8,),
                           Text("${data?.wind} km/h",style:  TextStyle(color: const Color.fromARGB(255, 4, 85, 151),fontSize: 15.sp),),
                            Text("Wind",style: TextStyle(color:  Color.fromARGB(255, 4, 85, 151),fontSize: 16.sp),)

                          ]
                        ),
                         SizedBox(width: 40.w,),
                         Column(
                          children: [
                           // Image.asset("name"),
                            Image.asset("assets/cloudy.png",scale: 9,),
                           Text("${data?.humdity}",style: TextStyle(color:  Color.fromARGB(255, 4, 85, 151),fontSize: 15.sp),),
                            Text("Humdity",style: TextStyle(color:  Color.fromARGB(255, 4, 85, 151),fontSize: 16.sp),)

                          ]
                        ),
                         SizedBox(width:20.w ,),
                         Column(
                          children: [
                           // Image.asset("name"),
                            Image.asset("assets/wind.png",scale: 5,),
                           Text("${data?.wind_dir}",style:  TextStyle(color:  Color.fromARGB(255, 4, 85, 151),fontSize: 15.sp),),
                            Text("Wind Direction",style: TextStyle(color:  Color.fromARGB(255, 4, 85, 151),fontSize: 16.sp),)

                          ]
                        )
                      ],)
                    ]
                  ),
                ),
                
                Container(
                  margin:  EdgeInsets.only(top: 270.h,),
                  // padding: EdgeInsets.only(bo),
                  decoration: const BoxDecoration(color: Colors.white),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () {
                               Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                (context)=>myplantPageScreen(growplants: myplanted)));

                                final List<Plant> growplants=Plant.getgrowPlants();
                                myplanted=growplants.toSet().toList();
                                
                            },
                            child: Container(
                              margin:  EdgeInsets.only(left: is_Arabic()?0.w:10.w ,top: 10.h,right: is_Arabic()?30.w:0.w),
                             decoration: const BoxDecoration(
                              borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(30),
                                topLeft: Radius.circular(30),
                                topRight: Radius.circular(30)
                              ),
                              color: Color.fromARGB(255, 37, 110, 66),
                          
                             ),
                              width: 163.w,height: 120.h,
                              child:Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  //image 
                                  Image.asset("assets/my_plants.png",scale: 4,color: const Color.fromRGBO(229, 242, 195, 1),),
                                   Center(child: Column(
                                    children: [
                                      SizedBox(height: 8.h,),
                                      Text(S.of(context).my_plants,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromRGBO(251, 251, 250, 1)),),
                                    ],
                                  ))
                                ],
                              )
                            ),
                          ),
                         // SizedBox(width: 4,),
                          Container(
                              margin:  EdgeInsets.only(left: is_Arabic()?0.w:20.w ,top: 0.h,right: is_Arabic()?30.w:0.w),
                           decoration: const BoxDecoration(
                           borderRadius: BorderRadius.only(
                              bottomRight: Radius.circular(30),
                              topLeft: Radius.circular(30),
                              topRight: Radius.circular(30)
                            ),
                            color: Color.fromARGB(255, 37, 110, 66),
                           ),
                            width: 163.w,height: 120.h,
                            child:Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                //image 
                                Image.asset("assets/new.png",color: const Color.fromRGBO(229, 242, 195, 1),),
                                //Center(child: Text("New",style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromRGBO(248, 225, 213, 1)),))
                              ],
                            )
                          ),
                        ],
                      ),
                    //  SizedBox(height: 2,),
                       Row(
                        children: [
                          Container(
 margin:  EdgeInsets.only(left: is_Arabic()?0.w:10.w ,top: 10.h,right: is_Arabic()?30.w:0.w),
                           decoration: const BoxDecoration(
                           borderRadius: BorderRadius.only(
                              bottomLeft: Radius.circular(30),
                              topLeft: Radius.circular(30),
                              bottomRight: Radius.circular(30)
                            ),
                            color: Color.fromARGB(255, 37, 110, 66),
                           ),
                            width: 163.w,height: 120.h,
                            child:Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                //image 
                                Image.asset("assets/discovery.png",scale: 3,color: const Color.fromRGBO(229, 242, 195, 1),),
                                 Center(child: Text(S.of(context).discovery,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromRGBO(251, 251, 250, 1)),))
                              ],
                            )
                          ),
                         // SizedBox(width: 4,),
                          GestureDetector(
                            onTap: () {
                                Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                (context)=>const Gadgets()));
                            },
                            child: Container(
                              margin:  EdgeInsets.only(left: is_Arabic()?0.w:20.w ,top: 10.h,right: is_Arabic()?30.w:0.w),
                             decoration: const BoxDecoration(
                             borderRadius: BorderRadius.only(
                                bottomLeft: Radius.circular(30),
                                bottomRight: Radius.circular(30),
                                topRight: Radius.circular(30)
                              ),
                              color: Color.fromARGB(255, 37, 110, 66),
                             ),
                              width: 163.w,height: 120.h,
                              child:Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  //image 
                                  Image.asset('assets/dashboard.png',color: const Color.fromRGBO(229, 242, 195, 1),),
                                   Center(child:
                                   Column(
                                     children: [
                                      SizedBox(height: 10.h,),
                                       Text(S.of(context).gadgets,style: TextStyle(fontSize: 20.sp,fontWeight: FontWeight.w500,color: Color.fromRGBO(251, 251, 250, 1)),),
                                     ],
                                   ))
                                ],
                              )
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  
                  )
                  
                  
             
               

      ],);
         },),
         
      
      
     
        
    );
    
  }
}