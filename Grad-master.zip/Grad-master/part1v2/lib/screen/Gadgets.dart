import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_switch/flutter_switch.dart';
import 'package:part1v2/generated/l10n.dart';
import 'package:part1v2/main.dart';
import 'package:part1v2/screen/home.dart';

class Gadgets extends StatelessWidget {
  const Gadgets({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body:
        SingleChildScrollView(
          child: Column(
            children: [
              Stack(
                children: [
                  
                  Container(
                  //  margin: const EdgeInsets.only(top: 140,),
                   decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 238, 236, 235),
                   // borderRadius: BorderRadius.only(topLeft: Radius.circular(65),
                   )
                    
                   ),
        
                   Container(
                          height: 200.h,width: double.infinity.w,
                          decoration: const BoxDecoration(
                          image: DecorationImage(image:AssetImage('assets/do.jpg'),
                          fit: BoxFit.cover),
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(150),
                            bottomRight: Radius.circular(150),
                          )
                        ),),
                  Positioned(
                    top: 60,left: 148,
                    child:
                     Text(S.of(context).gadgets,style: 
                     TextStyle(fontSize: 30,fontWeight:
                      FontWeight.bold,color: Colors.white),)),

                       Positioned(
                    top: 26.h,
                    child:IconButton(onPressed: (){
                      Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const homePage()));
                    },
                     icon: const Icon(Icons.arrow_back))
                       )
                  
                     
        
                ],
              ),

               SizedBox(height: 10.h,),
              SizedBox(
                height: 600.h,

                child: Column(
                  children: [
                    Row(
                      children: [
                        Padding(
                                padding:  EdgeInsets.only(top: 10.h,left: is_Arabic()?0.w:12.w
                                ,right: is_Arabic()? 16.w:0.w),
                                child: Container(height: 160.h,width: 160.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color.fromARGB(255, 224, 204, 198)
                                  ),
                                  child: Column(
                                    children: [
                                       Padding(
                                        padding: EdgeInsets.only(top:is_Arabic()?11.h:14.h),
                                        child: Text(S.of(context).soil_moisture,style: TextStyle(
                                          fontWeight: FontWeight.w700,fontSize: 22
                                        ),),
                                      ),
                                       SizedBox(height: 5.h,),
                                      Image.asset("assets/temperature.png",scale: 7,),
                                       Padding(
                                        padding: EdgeInsets.only(top: 10.h),
                                        child: Text("350 kkl",style: TextStyle(
                                          fontWeight: FontWeight.w900,fontSize: 18
                                        ),),
                                      ),
                                    ],
                                  ),
                                )
                                ),
                                Padding(
                                padding:  EdgeInsets.only(top: 10.h,left: is_Arabic()?0.w:12.w,right: is_Arabic()? 16.w:0.w),
                                child: Container(height: 160.h,width: 160.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color.fromARGB(255, 224, 204, 198)
                                  ),
                                  child: Column(
                                    children: [
                                       Padding(
                                        padding: EdgeInsets.only(top:is_Arabic()?11.h:14.h),
                                        child: Text(S.of(context).temperature,style: TextStyle(
                                          fontWeight: FontWeight.w900,fontSize: 19.sp
                                        ),),
                                      ),
                                       SizedBox(height: 5.h,),
                                      Image.asset("assets/temperature.png",scale: 7,),
                                       Padding(
                                        padding: EdgeInsets.only(top: 10.h,right: 16.w),
                                        child: Text("35",style: TextStyle(
                                          fontWeight: FontWeight.w700,fontSize: 18
                                        ),),
                                      ),
                                    ],
                                  ),
                                )
                                ),
                                

                                
                      ],
                    ),
                     SizedBox(height: 10.h,),
                    Row(
                      children: [
                             Padding(
                                padding:  EdgeInsets.only(top: 10.h,left: is_Arabic()?0.w:12.w,right: is_Arabic()? 16.w:0.w),

                                child: Container(height: 160.h,width: 160.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color.fromARGB(255, 224, 204, 198)
                                  ),
                                  child: Column(
                                    children: [
                                       Padding(
                                        padding: EdgeInsets.only(top: 14.h),
                                        child: Text(S.of(context).rain_sesor,style: TextStyle(
                                          fontWeight: FontWeight.w900,fontSize: 22
                                        ),),
                                      ),
                                       SizedBox(height: 5.h,),
                                      Image.asset("assets/rain.png",),
                                       Padding(
                                        padding: EdgeInsets.only(top: 14.h),
                                        child: Text("No Rain",style: TextStyle(
                                          fontWeight: FontWeight.w700,fontSize: 18
                                        ),),
                                      ),
                                    ],
                                  ),
                                )
                                ),

                                Padding(
                                 padding:  EdgeInsets.only(top: 10.h,left: is_Arabic()?0.w:12.w,right: is_Arabic()? 12.w:0.w),

                                child: Container(height: 160.h ,width: 160.w,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(20),
                                    color: const Color.fromARGB(255, 224, 204, 198)
                                  ),
                                  child: Column(
                                    children: [
                                       Padding(
                                        padding: EdgeInsets.only(top: 14.h),
                                        child: Text(S.of(context).faucet,style: TextStyle(
                                          fontWeight: FontWeight.w900,fontSize: 22
                                        ),),
                                      ),
                                       SizedBox(height: 10.h,),
                                      Image.asset("assets/faucet.png",scale: 10,),
                                       Padding(
                                        padding: EdgeInsets.only(top: 12.h),
                                        child: Switch_Button()
                                      ),
                                    ],
                                  ),
                                )
                                ),
                      ],
                    ),
                     SizedBox(height: 10.h,),
                    Container(
                            width: 370.w,
                             
                             height: 130.h,
                            margin:  EdgeInsets.symmetric(vertical: 7.h, horizontal: 15.w),
                            child: Row(
                              children: [
                             
                                Container(
                                  width: 150.w,
                                  decoration: const BoxDecoration(
                                    color: Colors.white
                                  ),
                                  child: Image.asset("assets/25004.png"),
                                  ),
                              
                              ///plant name
                                 Padding(
                                  padding: EdgeInsets.only(top:30.h,left: 7.w),
                                  child: Column(
                                    children: [
                                      Text(
                                    S.of(context).soba_controller,
                                    style: TextStyle(
                                         fontSize: 22, fontWeight: FontWeight.w900),
                                  ),
                                  SizedBox(height: 26.h,),
                                  Switch_Button()
                                    
                                    ],
                                
                                
                                  ),
                                )

                              ],
                            ),
                     
                            decoration: BoxDecoration(
                             color: const Color.fromARGB(255, 224, 204, 198).withOpacity(.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                    
                            
                      

                        ],
                      ),
              )

          
                  ],
                ),
              )


            
          );
        
        
      
    
  }
}

class Switch_Button extends StatefulWidget {
  const Switch_Button({super.key});

  @override
  _Switch_ButtonState createState() => _Switch_ButtonState();
}

class _Switch_ButtonState extends State<Switch_Button> {
  bool isOn = false;

  @override
  Widget build(BuildContext context) {
    return FlutterSwitch(
      // width: 20.0,
      // height: 30.0,
      valueFontSize: 12.0,
      toggleSize: 25.0,
      value: isOn,
      borderRadius: 15.0,
      toggleColor: const Color.fromRGBO(248, 225, 213, 1),
      padding: 2.0,
      showOnOff: true,
      activeColor: const Color.fromRGBO(122, 61, 59, 1),
      onToggle: (val) {
        setState(() {
          isOn = val;
        });
      },
    );
  }
}