import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:part1v2/constant/fertllizers.dart';
import 'package:part1v2/screen/fertllizersmarDetails.dart';

class fertllizersmarket extends StatefulWidget {
  const fertllizersmarket({super.key});

  @override
  State<fertllizersmarket> createState() => _fertllizersmarketState();
}

class _fertllizersmarketState extends State<fertllizersmarket> {
  List<fertllizers> _fertllizersmarketlist=fertllizers.fertllizersList;
  @override
  Widget build(BuildContext context) {
     Size size = MediaQuery.of(context).size;
    return Scaffold(
      body:
       SingleChildScrollView(
       //  scrollDirection: Axis.vertical,
         child: Column(
          children: [
          SizedBox(
            height: size.height *0.9 ,
            child: 
               Padding(
                 padding: const EdgeInsets.only(top:16.0,left: 16,right: 16,bottom: 16),
                 child: 
                 GestureDetector(
                  onTap: () {
                    // Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>
                    // fertllizersmarDetails(fertllizersidmarket: _fertllizersmarketlist[index].fertllizersId)));
                  },
                  child:
                   gridwidget(
                    
                    fertllizersmarketlist: _fertllizersmarketlist)),
               )
                
              ),
         ]
        
       )
    )
    );
  }
}

class gridwidget extends StatelessWidget {
  const gridwidget({
    super.key,
    required List<fertllizers> fertllizersmarketlist,
  }) : _fertllizersmarketlist = fertllizersmarketlist;

  final List<fertllizers> _fertllizersmarketlist;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: GridView.builder(
       physics: NeverScrollableScrollPhysics(),
       shrinkWrap: true,
       itemCount: _fertllizersmarketlist.length,
       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
         crossAxisCount: 2,
         crossAxisSpacing: 15,
         mainAxisExtent: 230,
         mainAxisSpacing: 12),
        itemBuilder: (BuildContext context,int index) {
         return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Color.fromARGB(255, 74, 149, 104),
          ),
          child: Column(
            children: [
               Container(
                height: 160,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 240, 239, 239),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),topRight: Radius.circular(15),
                    bottomLeft: Radius.circular(95),bottomRight: Radius.circular(95)
                    )
                ),
                 child: 
                    GestureDetector(
                      onTap: () {
                         Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>
                    fertllizersmarDetails(fertllizersidmarket: _fertllizersmarketlist[index].fertllizersId)));
                      },
                      child: 
                      Stack(
                        children: [
                          Image.asset(_fertllizersmarketlist[index].imageURL,height: 180,width: double.infinity,),
                            Positioned(
                              right: 5,
                              child: IconButton(onPressed: (){}, 
                                                      icon: Icon(CupertinoIcons.heart)),
                            )
                        ],
                      )),
                 ),

                // SizedBox(height: ,),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                   children: [
                     Text("${_fertllizersmarketlist[index].fertllizersName}",
                          style: Theme.of(context).textTheme.subtitle1?.merge(TextStyle(
                          fontWeight: FontWeight.bold,fontSize: 20,color: Color.fromARGB(255, 243, 240, 240)
                          ))
                          ),
                          // IconButton(onPressed: (){}, 
                          // icon: Icon(CupertinoIcons.heart))
                   ],
                 ),
                      SizedBox(height: 7,),
                       Text("${_fertllizersmarketlist[index].price} \$ ",
                      style: Theme.of(context).textTheme.subtitle2?.merge(TextStyle(
                      fontWeight: FontWeight.w700,fontSize: 18,color: Colors.white
                      ))
                      ),
    
            ]
          ),
         );
          
        },),
    );
  }
}
