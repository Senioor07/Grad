import 'package:flutter/material.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/homeScreen.dart';
import 'package:part1v2/screen/plantmarket.dart';
import 'package:part1v2/screen/myPlantsScreen.dart';
import 'package:part1v2/screen/searchScreen.dart';

import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class New extends StatefulWidget {
  const New({super.key});

  @override
  State<New> createState() => _NewState();
}

class _NewState extends State<New> {
  bool isLastPage = false;
  final controller = PageController();
 // final scaffoldKey = GlobalKey<ScaffoldState>(); 
// List<Plant> myplanted=[];
  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }
  void alert(BuildContext context) {
   showDialog(
  context: context,
  builder: (BuildContext context) {
    return AlertDialog(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1), 
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(30.0), 
      ),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'The plant has been planted',
            style: TextStyle(fontSize: 16.0),
          ),
          SizedBox(height: 20.0), 
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              TextButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => homePage(),
                    ),
                  );
                },
                child: Text(
                  'OK',
                  style: TextStyle(
                    color:  Color.fromARGB(255, 110, 37, 37),
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  },
);
}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
        body:  Container(
        
           decoration: BoxDecoration(
              color: Color.fromRGBO(248, 225, 213, 1),
              borderRadius: BorderRadius.circular(10.0),
            ),
          padding: EdgeInsets.only(bottom: 80),
          child: PageView(
            controller: controller,
            onPageChanged: (index) {
              setState(() => isLastPage = index == 2);
            },
            
            children: [
            //  IconButton(onPressed: (){}, icon: Icon(Icons.arrow_back_ios)),
              Center(
                 child: Container(
                  padding: EdgeInsets.all(10),
         
           
            child: Column(
              
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/step1.png',
                  height: 280,
                  
                ),
                SizedBox(height: 20),
                Text('Step 1',style: TextStyle(fontSize: 30),),
                SizedBox(height: 20),
                Text(
                  'First you must plant the seeds in the soil',style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
              ),
             Center(
                 child: Container(
                  padding: EdgeInsets.all(10),
         
           
            child: Column(
              
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/step2.png',
                  height: 280,
                  
                ),
                SizedBox(height: 20),
                Text('Step 2',style: TextStyle(fontSize: 30),),
                SizedBox(height: 20),
                Text(
                  'Secondly, you must pay attention to the plant and know the times for watering it',style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
              ),
              Center(
                 child: Container(
                  padding: EdgeInsets.all(10),
         
           
            child: Column(
              
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/step3.png',
                  height: 280,
                  
                ),
                SizedBox(height: 20),
                Text('Step 3',style: TextStyle(fontSize: 30),),
                SizedBox(height: 20),
                Text(
                  'Now leave the plant in the sun to carry out photosynthesis.',style: TextStyle(fontSize: 20),
                ),
              ],
            ),
          ),
              ),
            ],
          ),
        ),
        bottomSheet: isLastPage
            ? TextButton(
                style: TextButton.styleFrom(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(5)),
                  primary: Color.fromARGB(255, 110, 37, 37),
                  backgroundColor: Color.fromARGB(255, 110, 37, 37),
                  minimumSize: const Size.fromHeight(80),
                ),
                onPressed: () {
                   
                                alert(context);
                  // Navigator.push(
                  //   context,
                  //   MaterialPageRoute(builder: (context) => homePage()),
                  // );
                },
                child: Text(
                  'Start Growing',
                  style: TextStyle(
                    fontSize: 24,
                    color:  Color.fromRGBO(248, 225, 213, 1),
                  ),
                ),
              )
            : Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                height: 80,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // TextButton(
                    //   child: Text('Skip'),
                    //   onPressed: () => controller.jumpToPage(2),
                    // ),
                    Center(
                      child: SmoothPageIndicator(
                        
                        controller: controller,
                        count: 3,
                        effect: WormEffect(
                          activeDotColor:
                              Color.fromARGB(255, 110, 37, 37),
                          dotColor: Colors.grey,
                        ),
                      ),
                    ),
                    TextButton(
                      onPressed: () => controller.nextPage(
                          duration: Duration(milliseconds: 500),
                          curve: Curves.easeInOut),
                      child: Icon(Icons.arrow_forward),
                    )
                  ],
                ),
              ),
      )
    ;
  }
}
