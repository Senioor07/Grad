import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:part1v2/constant/Tools.dart';
import 'package:part1v2/screen/toolsmarDetails.dart';

class toolsmarket extends StatefulWidget {
  const toolsmarket({super.key});

  @override
  State<toolsmarket> createState() => _toolsmarketState();
}

class _toolsmarketState extends State<toolsmarket> {
  List<tools> _toolsmarketlist=tools.toolsList;
  @override
  Widget build(BuildContext context) {
     Size size = MediaQuery.of(context).size;
    return Scaffold(
      body:
       SingleChildScrollView(
       //  scrollDirection: Axis.vertical,
         child: Column(
          children: [
          SizedBox(
            height: size.height *0.9 ,
            child: 
               Padding(
                 padding: const EdgeInsets.only(top:16.0,left: 16,right: 16,bottom: 16),
                 child: 
                 GestureDetector(
                  onTap: () {
                    // Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>
                    // toolsmarDetails(toolsidmarket: _toolsmarketlist[index].toolsId)));
                  },
                  child:
                   gridwidget(
                    
                    toolsmarketlist: _toolsmarketlist)),
               )
                
              ),
         ]
        
       )
    )
    );
  }
}

class gridwidget extends StatelessWidget {
  const gridwidget({
    super.key,
    required List<tools> toolsmarketlist,
  }) : _toolsmarketlist = toolsmarketlist;

  final List<tools> _toolsmarketlist;

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: GridView.builder(
       physics: NeverScrollableScrollPhysics(),
       shrinkWrap: true,
       itemCount: _toolsmarketlist.length,
       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
         crossAxisCount: 2,
         crossAxisSpacing: 15,
         mainAxisExtent: 230,
         mainAxisSpacing: 12),
        itemBuilder: (BuildContext context,int index) {
         return Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(15),
            color: Color.fromARGB(255, 74, 149, 104),
          ),
          child: Column(
            children: [
               Container(
                height: 160,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 240, 239, 239),
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(15),topRight: Radius.circular(15),
                    bottomLeft: Radius.circular(95),bottomRight: Radius.circular(95)
                    )
                ),
                 child: 
                    GestureDetector(
                      onTap: () {
                         Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>
                    toolsmarDetails(toolsidmarket: _toolsmarketlist[index].toolsId)));
                      },
                      child: 
                      Stack(
                        children: [
                          Image.asset(_toolsmarketlist[index].imageURL,height: 180,width: double.infinity,),
                            Positioned(
                              right: 5,
                              child: IconButton(onPressed: (){}, 
                                                      icon: Icon(CupertinoIcons.heart)),
                            )
                        ],
                      )),
                 ),

                // SizedBox(height: ,),
                 Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                   children: [
                     Text("${_toolsmarketlist[index].toolsName}",
                          style: Theme.of(context).textTheme.subtitle1?.merge(TextStyle(
                          fontWeight: FontWeight.bold,fontSize: 20,color: Color.fromARGB(255, 243, 240, 240)
                          ))
                          ),
                          // IconButton(onPressed: (){}, 
                          // icon: Icon(CupertinoIcons.heart))
                   ],
                 ),
                      SizedBox(height: 7,),
                       Text("${_toolsmarketlist[index].price} \$ ",
                      style: Theme.of(context).textTheme.subtitle2?.merge(TextStyle(
                      fontWeight: FontWeight.w700,fontSize: 18,color: Colors.white
                      ))
                      ),
    
            ]
          ),
         );
          
        },),
    );
  }
}
