import 'package:flutter/material.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/generated/l10n.dart';
import 'package:part1v2/main.dart';
import 'package:part1v2/screen/myPlantsScreen.dart';

class plantcareScreen extends StatefulWidget {
  const plantcareScreen({super.key});

  @override
  State<plantcareScreen> createState() => _plantcareScreenState();
}
List<Plant> myplanted=[];
class _plantcareScreenState extends State<plantcareScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body:Stack(
        children: [
           Image.asset('assets/k13.jpg',width: double.infinity,fit: BoxFit.cover,),
           
           SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 50,),
             Padding(
             padding: const EdgeInsets.only(right: 330),
             child: IconButton(onPressed: (){
                 Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                  (context)=>myplantPageScreen(growplants: myplanted)));
             },
              icon:Icon(Icons.arrow_back_ios) ),
           ),
            Row(
              children: [
                Padding(
                  padding:  EdgeInsets.only(left: is_Arabic()?0:35,top: 5,right: is_Arabic()?35:0),
                  child: Column(
                    children: [
                      
                      
                      Image.asset("assets/pic23.png",scale: 2,),
                      Text(S.of(context).sansevera,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w800),)
                    ],
                  ),
                ),
                SizedBox(width: 25,),
               Container(
                width: 1,
                height: 240,
                color: Colors.black,
               ),
                SizedBox(width: 14,),
               Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                 children: [
                   Text(S.of(context).Origin,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                   SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).Soil,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).Light,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).Humdity,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).temperature,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).fertilizer,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: is_Arabic()?5:10,),
                   Text(S.of(context).Caredifficulty,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                   SizedBox(height: is_Arabic()?5:10,),
                   
                   Text(S.of(context).Watering,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  
                 ],
               )
      
              ],
            ),
            SizedBox(height: is_Arabic()?20:50,),
            Container(
              height: 1,
              width: 350,
              color: Colors.black,
            ),
             SizedBox(height: 45,),
            Padding(
              padding:  EdgeInsets.only(left: is_Arabic()?0:85,right: is_Arabic()?85:0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                   Text(S.of(context).PlantingDate,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                   SizedBox(height: 13,),
                  Text(S.of(context).LastWatering,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),), 
                  SizedBox(height: 13,),
                  Text(S.of(context).NextWatering,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                  SizedBox(height: 13,),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(S.of(context).Health,style: TextStyle(fontSize: 20,fontWeight: FontWeight.w500),),
                      SizedBox(width: 20,),
                      Image.asset('assets/code-scan.png',height: 30,color: Color.fromARGB(255, 57, 148, 36),)
                    ],
                  )
                ],
            
              ),
            ),
           
            
          ]
        ),
      ),
        ],
      )
    );
  }
}