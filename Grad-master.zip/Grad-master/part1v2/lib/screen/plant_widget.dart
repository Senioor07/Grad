import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/detailsplant.dart';

class plantwidget extends StatelessWidget {
  const plantwidget({super.key, required this.index, required this.plantList});
  final int index;
  final List<Plant> plantList;
  
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              PageTransition(
                                child: detailsplantSceen(plantId:  plantList[index].plantId),
                                type: PageTransitionType.bottomToTop,
                              ),
                            );
                          },
                          child: Container(
                            width: 370,
                             
                             height: 80,
                            margin: EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                            child: Row(
                              children: [
                                ///imageurl
                                Container(
                                  width: 80,
                                  decoration: BoxDecoration(
                                    color: Colors.white
                                  ),
                                  child: Image.asset(plantList[index].imageURL)),
                              
                              ///plant name
                                Padding(
                                  padding: const EdgeInsets.only(top:25,left: 40),
                                  child: Column(
                                    children: [
                                      Text(
                                   plantList[index].plantName,
                                    style: TextStyle(
                                        color: Colors.white70, fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                      Text(
                                     plantList[index].category,
                                    style: TextStyle(color: Colors.white70, fontSize: 20),
                                  ),
                                    
                                    ],
                                
                                
                                  ),
                                )

                              ],
                            ),
                     
                            decoration: BoxDecoration(
                             color: Color.fromRGBO(122, 61, 59, 1).withOpacity(.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        );
  }
}