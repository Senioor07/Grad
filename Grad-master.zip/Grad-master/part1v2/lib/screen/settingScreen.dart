import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:part1v2/constant/global_var.dart';
import 'package:part1v2/screen/drawer.dart';
import 'package:part1v2/screen/editProfile.dart';

import '../generated/l10n.dart';

class SettingScreenpage extends StatefulWidget {
  const SettingScreenpage({super.key});

  @override
  State<SettingScreenpage> createState() => _SettingScreenpageState();
}

class _SettingScreenpageState extends State<SettingScreenpage> {
  String selectedLanguage = 'ar';

  void change_lang (){
    setState(() {
      lang = selectedLanguage;
      if(selectedLanguage == 'ar')
      selectedLanguage = 'en';
      else
       selectedLanguage = 'ar';
      

    }
    );
  }
  @override
   
  Widget build(BuildContext context) {
    return Scaffold(
       body:Stack(
        children: [
         
          Image.asset('assets/walpaber8.jpg',fit: BoxFit.cover,width: double.infinity),
           Padding(
            padding: const EdgeInsets.only(top:28),
            child: IconButton(onPressed: (){
            Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const mydrawer()));
                  }, icon: const Icon(Icons.arrow_back_ios_new_outlined,color: Color.fromARGB(255, 66, 142, 68),
                  )),
          ),
          
                Padding(
                padding: EdgeInsets.only(top:120.0,left: 145,right: 145),
                child: Text(
                  S.of(context).title,style: TextStyle(fontSize: 30,fontWeight: FontWeight.bold),
                ),
              ),
            
           Container(
          
            margin: const EdgeInsets.only(top: 180),
        padding: const EdgeInsets.only(top: 25,left: 16,right: 16),
        child: ListView(
          children: [
            const SizedBox(height: 40,),
             Row(children:
             [Icon(Icons.person,
             color: Color.fromARGB(184, 46, 85, 25),),
             Text(S.of(context).account,style: TextStyle(fontSize: 17,fontWeight: FontWeight.w800),)
             ],
             ),
             const Divider(height: 15,thickness: 2,),
             const SizedBox(height: 20,),
              GestureDetector(
                onTap: (){
                  Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const editProfileScreen()));
                },
                child: Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Color.fromRGBO(193, 85, 49, 0.8)
                ),
                height: 50,
                  child:  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Padding(
                        padding: EdgeInsets.all(8.0),
                        child: Text(    
                          S.of(context).edit_profile,style: TextStyle(fontSize: 20),),
                      ),
                      Icon(Icons.arrow_forward_ios)
              
                    ],
                  ),
                  
                  ),
              ),
              const SizedBox(height: 10,),
                GestureDetector(
                onTap: (){
                
                },
                child: Container(
                decoration:  BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Color.fromRGBO(193, 85, 49, 0.8)
                ),
                height: 50,
                   child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
           Padding(
            padding: EdgeInsets.all(8.0),
            child: Text(
             S.of(context).language,
              style: TextStyle(fontSize: 20),
            ),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
                            primary: Color.fromARGB(159, 3, 92, 6),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              
                            ),
                              minimumSize: Size(90, 40), //width 
                           maximumSize: Size(90, double.infinity), 
                          ),
            onPressed: (){
            
            change_lang();
          }, child: Text(lang))
          
          // DropdownButton<String>(
          //   value: selectedLanguage,
          //   icon: const Icon(Icons.keyboard_arrow_down_rounded, size: 40),
          //   onChanged: 
          //   ( newValue) {
          //     setState(() {
          //       selectedLanguage = newValue!;
          //     });
          //   },
          //   items: <String>['ara', 'ena']
          //       .map<DropdownMenuItem<String>>((String value) {
          //     return DropdownMenuItem<String>(
          //       value: value,
          //       child: Text(value),
          //     );
          //   }).toList(),
          // ),
        ],
      ),
                  
                  ),
              ),
              const SizedBox(height: 10,),
              Container(
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10)),
                  color: Color.fromRGBO(193, 85, 49, 0.8)
                ),
                height: 50,
                  child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                 Padding(
                  padding: EdgeInsets.all(8.0),
                  child: Text(S.of(context).dar_mode,style: TextStyle(fontSize: 20,
                 ),),
                ),
                Transform.scale(scale: 0.7,
                child: CupertinoSwitch(
                  value: false,
                   onChanged: (bool val){},),
                )
              ]
             ),),
             
              const SizedBox(height: 30,),
               Row(children:
             [Icon(Icons.volume_up_outlined,color: Color.fromARGB(184, 46, 85, 25),),
             Text(S.of(context).notification,style: 
             TextStyle(fontSize: 17,fontWeight: FontWeight.w800),)
             ],
             ),
             const SizedBox(height: 5,),
             const Divider(height: 8,thickness: 2,),
             const SizedBox(height: 5,),
             Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children:[
                 Text(S.of(context).new_for_you,style: TextStyle(fontSize: 17,fontWeight: FontWeight.w800),),
                Transform.scale(scale: 0.7,
                child: CupertinoSwitch(
                  value: true,
                   onChanged: (bool val){},),
                )
              ]
             ),
             const SizedBox(height: 10,),
            
              
              
             
          ],
        ),
       ),
        ],
       )
    );
  }
}