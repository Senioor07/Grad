import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/plantmarket.dart';
import 'package:part1v2/screen/myPlantsScreen.dart';
import 'package:part1v2/screen/stepGrow.dart';

class detailsplantSceen extends StatefulWidget {
  const detailsplantSceen({super.key, required this.plantId});
  final int plantId;


   
  @override
  State<detailsplantSceen> createState() => _detailsplantSceenState();
}

class _detailsplantSceenState extends State<detailsplantSceen> {
  
  bool toggleIsselected(bool isSelected){
    return !isSelected;
  }
  
  @override
  Widget build(BuildContext context) {
      Size size = MediaQuery.of(context).size;
    List<Plant> _plantList = Plant.plantList;
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
            color: Color.fromRGBO(122, 61, 59, 1),
            
           
          ),),
            Positioned(
            top: 50.h,
            left: 20.w,
            right: 20.w,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                GestureDetector(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Container(
                    height: 40.h,
                    width: 40.w,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(25),
                      color: Color.fromARGB(255, 110, 37, 37)
                    ),
                    child: Icon(
                      Icons.close,
                      color:  Colors.green,
                    ),
                  ),
                ),
                
              ],
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 240.h),
            decoration: BoxDecoration(
            color: Color.fromRGBO(248, 225, 213, 1),
             borderRadius: BorderRadius.only(
               topLeft: Radius.circular(110),
              topRight: Radius.circular(110)
             )
           
          ),),
          Positioned(
            top: 230.h,
            left: 24.w,
            
            child: Icon(
              Icons.arrow_back_ios_new_outlined,size: 70,
              color: Color.fromARGB(255, 15, 80, 17),)),
              Positioned(
            top: 230.h,
            right: 24.w,
            
            child: Icon(
              Icons.arrow_forward_ios_outlined,size: 70,
              color: Color.fromARGB(255, 15, 80, 17),)),

          Positioned(
            top: 60.h,
            left: 28.w,
            right: 26.w,
            child: Container(
              width: size.width * .8.w,
              height: size.height * .8.h,
              padding: const EdgeInsets.all(20),
              child: Stack(
                children: [
                  Positioned(
                    top: 1.h,
                    left: 25.w,
                    child: SizedBox(
                      height: 250.h,
                      child: Image.asset(_plantList[widget.plantId].imageURL),
                    ),
                  ),
                  Positioned(
                    top: 300.h,
                   // right: 80,
                   left: 25.w,
                    child: SizedBox(
                      height: 100.h,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        children: [
                        
                         
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              PlantFeature(
                                title: 'Humidity',
                                plantFeature:
                                    _plantList[widget.plantId].humidity.toString(),
                              ),
                              SizedBox(width: 45.w,),
                                 ElevatedButton(
                            onPressed: () {
                              
             
                            setState(() {
                               Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                (context)=>New()));
                              bool isSelected=toggleIsselected(_plantList[widget.plantId].isSelected);
                              _plantList[widget.plantId].isSelected=isSelected;
                            });
                            
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Color.fromARGB(255, 74, 149, 104),
                              shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                                
                              ),
                                minimumSize: Size(100, 50), //width 
                             maximumSize: Size(140, double.infinity), 
                            ),
                            child: Text(
                             "Growing",
                             style: TextStyle(color: Colors.white,
                             fontSize: 18.sp),
                                                            ),
                          ),
                        
                            ],
                          ),
                          PlantFeature(
                            title: 'Temperature',
                            plantFeature:
                                _plantList[widget.plantId].temperature,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          Positioned(
            bottom: 310.h,
            left: 110.w,
            right: 0.w,
            child:Text(
                      _plantList[widget.plantId].plantName,
                      style: TextStyle(
                       color: Color.fromARGB(255, 49, 108, 51),
                      fontWeight: FontWeight.bold,
                      fontSize: 30.0.sp,
                            ),
                          ),
                          
                         
                        
                       ),
                      // Positioned(
                      //   bottom: 50,
                      //   left: 10,
                      //   right: 10,
                      //   child: Container(
                      //     decoration: BoxDecoration(
                      //       gradient: LinearGradient(
                      //        colors: [
                      //        Color.fromRGBO(204, 139, 115, 1),
                      //       Color.fromARGB(255, 218, 218, 188)],
                      //      ),
                      //     ),


                      ///container discription
                           Positioned(
                                    bottom: 7.h,
                                    left: 20.w,
                                    right: 20.w,
                                    child:Container(

                                      decoration: BoxDecoration(
                                        gradient: LinearGradient(colors: [
                                          const Color.fromARGB(221, 215, 176, 176),
                                          Color.fromARGB(255, 74, 149, 104)])
                                      ),
                                      
                                        child: Padding(
                                          padding: const EdgeInsets.all(8.0),
                                          child: Text(
                                            
                                                                  _plantList[widget.plantId].decription,
                                                                  textAlign: TextAlign.justify,
                                                                  style: TextStyle(
                                                                   // backgroundColor: Color.fromARGB(255, 230, 186, 170),
                                                                    height: 2.h,
                                                                    fontSize: 18.sp,
                                                                    color: Color.fromRGBO(122, 61, 59, 1),
                                                                  ),
                                                  ),
                                        ),
                                      
                                    ),
                              
                             
                            
                          ),
                        
                      
                    
                    
                  
              
                  // const SizedBox(
                  //   height: 5.0,
          //         ),
          //         Expanded(
                    // child: Text(
                    //   _plantList[widget.plantId].decription,
                    //   textAlign: TextAlign.justify,
                    //   style: TextStyle(
                    //     height: 1.5,
                    //     fontSize: 18,
                    //     color: Colors.green
                    //   ),
                    // ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
        ],
      ),
        
      
    );
  }
}

class PlantFeature extends StatelessWidget {
  final String plantFeature;
  final String title;
  const PlantFeature({
    Key? key,
    required this.plantFeature,
    required this.title,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 19.0.sp,
            color:Color.fromARGB(255, 49, 108, 51),
          ),
        ),
        Text(
          plantFeature,
          style: TextStyle(
            color: Color.fromARGB(255, 49, 108, 51),
            fontSize: 19.0.sp,
            fontWeight: FontWeight.bold,
          ),
        )
      ],
    );
  }
}