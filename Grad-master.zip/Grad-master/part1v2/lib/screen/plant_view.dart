import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/screen/home.dart';
class plant_view extends StatelessWidget {
  final File image;

  const plant_view({required this.image});

  @override
  Widget build(BuildContext context) {
     return 
 Scaffold(
    backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(248, 225, 213, 1),
        elevation: 0,
        leading:  IconButton(
          onPressed: (){
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
          },
           icon: Icon(Icons.arrow_back_outlined,color:Color.fromARGB(255, 15, 80, 17),)),
      ),
          body: ListView(
            children: [
              
              ClipRRect(
                
                borderRadius: BorderRadius.circular(30.0),
                child: SizedBox(
                  child: 
                      Image.file( image,
                         
                          height: 350,
                           fit: BoxFit.cover,
                        )
                
                  
                )
               
              ),
            
              Container(
                width: 300.w,
                height: 250.h,
                margin: EdgeInsets.only(
                    bottom: 30.h, left: 30.w, right: 30.w, top: 10.h),
                padding: EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: Color.fromARGB(255, 110, 37, 37),
                  border: Border.all(
                    color: Color.fromARGB(
                        255, 110, 37, 37), 
                    width: 2.0.w, 
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(30)),
                ),
                child: Text(
                  'Plants are the eukaryotes that form the kingdom Plantae; they are predominantly photosynthetic. This means that they obtain their energy from sunlight, using chloroplasts derived from endosymbiosis with cyanobacteria to produce sugars from carbon dioxide and water, using the green pigment chlorophyll. Exceptions are parasitic plants that have lost the genes for chlorophyll and photosynthesis, and obtain their energy from other plants or fungi.',
                  style: TextStyle(
                    fontSize: 30,
                    color: Color.fromRGBO(248, 225, 213, 1),
                  ),
                ),
              ),
              // MaterialButton(
              //     color: Colors.amber,
              //     onPressed: () {
              //       _getimage();
              //     }),
            ],
          ),
        );
  }
}