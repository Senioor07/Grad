import 'package:flutter/material.dart';
import 'package:part1v2/generated/l10n.dart';
import 'package:part1v2/screen/contactScreen.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/login.dart';
import 'package:part1v2/screen/settingScreen.dart';

class mydrawer extends StatelessWidget {
  const mydrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 230,
      child: Drawer(
        
        surfaceTintColor:Colors.red,
        backgroundColor: const Color.fromARGB(255, 244, 242, 242),
        child: Column(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                //color: const Color.fromARGB(255, 32, 121, 165),
              ),
              child: Icon(Icons.person,color: Color.fromRGBO(122, 61, 59, 1),size: 60,)),
            Padding(
              
              padding: const EdgeInsets.only(left:10.0),
              child: ListTile(
                leading: const Icon(Icons.home_filled,color: Color.fromRGBO(122, 61, 59, 1),),
                onTap: (){
                   Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const homePage()));
                },
                title: 
               Text(S.of(context).home,style:TextStyle(fontSize:25),),
              ),
    
            ),
            Padding(
              
              padding: const EdgeInsets.only(left:10.0),
              child: ListTile(
                leading: const Icon(Icons.settings,color: Color.fromRGBO(122, 61, 59, 1),),
                onTap: (){
                  Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const SettingScreenpage()));
                },
                title: 
               Text(S.of(context).setting,style:TextStyle(fontSize:25),),
              ),
              
            ),
            Padding(
              
              padding: const EdgeInsets.only(left:10.0),
              child: ListTile(
                leading: const Icon(Icons.contact_emergency,color: Color.fromRGBO(122, 61, 59, 1),),
                onTap: (){
                Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>const contactScreenPage()));
                },
                title: 
               Text(S.of(context).contact_us,style:TextStyle(fontSize:25),),
              ),
              
            ),
                Padding(
              
              padding: const EdgeInsets.only(left:10.0),
              child: ListTile(
                leading: const Icon(Icons.logout_rounded,color: Color.fromRGBO(122, 61, 59, 1),),
                onTap: (){
                   Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>SignupScreen()));
                },
                title: 
               Text(S.of(context).log_out,style:TextStyle(fontSize:25),),
              ),
              
            ),
          ],
        ),
      ),
    );
  }
}