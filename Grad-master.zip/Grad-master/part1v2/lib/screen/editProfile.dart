import 'package:flutter/material.dart';
import 'package:part1v2/generated/l10n.dart';
import 'package:part1v2/main.dart';
import 'package:part1v2/screen/settingScreen.dart';

class editProfileScreen extends StatefulWidget {
  const editProfileScreen({super.key});

  @override
  State<editProfileScreen> createState() => _editProfileScreenState();
}

class _editProfileScreenState extends State<editProfileScreen> {
  bool showpass=false;
  String selectedLanguage = 'Female';
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Stack(
        children: [
           Image.asset('assets/pictures.jpeg',fit: BoxFit.fill,width: double.infinity,),
          
          Container(
          
          child: GestureDetector(
            onTap: ()=> FocusScope.of(context).unfocus(),
            child: ListView(
              children: [
                
                Row(
                  children: [
                    IconButton(icon:Icon(Icons.arrow_back,color: Color.fromARGB(255, 238, 235, 235),),
                  onPressed: (){
                     Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>SettingScreenpage()));
                  }),
                    Padding(
                      padding:  EdgeInsets.only(top:27,left: is_Arabic()?0:80,right: is_Arabic()?80:0),
                      child: Text(S.of(context).EditProfile,style: TextStyle(fontSize: 27,fontWeight: FontWeight.bold,color: Colors.white),),
                    ),
                  ],
                ),
                
                SizedBox(height: 50,),
                Center(
                  child: Stack(
                    children: [
                      Container(width: 130,height: 130,
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 4,
                          color: Theme.of(context).scaffoldBackgroundColor,
                        ),
                        boxShadow:[ BoxShadow(
                          spreadRadius: 2,blurRadius: 10,
                          color: Colors.black.withOpacity(.1),
                          offset: Offset(0, 10)
                        ),],
                        shape: BoxShape.circle,
                        image: DecorationImage(image:
                         AssetImage('assets/profile.jpg'),fit:BoxFit.cover)
                      ),),
                       Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  width: 4,
                                  color: Theme.of(context).scaffoldBackgroundColor,
                                ),
                                color: Color.fromARGB(255, 111, 30, 8),
                              ),
                              child: Icon(
                                Icons.camera_alt_rounded,
                                color: Colors.white,
                              ),
                            )),
                    ],
                  ),
                ),
                SizedBox(height: 8,),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: textfields(S.of(context).FullName,S.of(context).fatma,false),
                ),
                //SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: textfields(S.of(context).Email,S.of(context).fatmagmail,false),
                ),
                //SizedBox(height: 10,),
                Padding(
                  padding: const EdgeInsets.all(15),
                  child: textfields(S.of(context).password,S.of(context).secret,true),
                ),
                SizedBox(height: 15,),
              //  Divider(height: 5,),
               
                // Padding(
                //   padding: const EdgeInsets.all(15.0),
                //   child: Row(
                //         mainAxisAlignment: MainAxisAlignment.spaceBetween,
                //         children: [
                //           Padding(
                //             padding: const EdgeInsets.all(8.0),
                //             child: Text(
                //               S.of(context).Gender,
                //               style: TextStyle(fontSize: 20, ),
                //             ),
                //           ),
                //           DropdownButton<String>(
                //             value: selectedLanguage,
                //             icon: Icon(Icons.keyboard_arrow_down_rounded, size: 40),
                //             onChanged: 
                //             ( newValue) {
                //               setState(() {
                //   selectedLanguage = newValue!;
                //               });
                //             },
                //             items: <String>[S.of(context).Female,S.of(context).Male] // 
                //   .map<DropdownMenuItem<String>>((String value) {
                //               return DropdownMenuItem<String>(
                //   value: value,
                //   child: Text(value),
                //               );
                //             }).toList(),
                //           ),
                //         ],
                //       ),
                // ),
               //Divider(height: 5,),
                 SizedBox(height: 50,),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                            onPressed: () {
                               
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Color.fromRGBO(122, 61, 59, 1),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                
                              ),
                                minimumSize: Size(100, 50), //width 
                             maximumSize: Size(100, double.infinity), 
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                
                                 Text(
                                  S.of(context).SAVE,
                                  style: TextStyle(color: Colors.white),
                                ),
                              ],
                            ),
                          ),
                        
              
           
                  ],
                )
                
              ]
            ),
          ),
        ),
        ],
         
      ),
      
    );
  }

  TextField textfields(String labeltext,String x,bool ispassword) {
    return TextField(
              obscureText: ispassword?showpass:false,
              decoration: InputDecoration( 
                suffixIcon: ispassword?
                IconButton(
                  onPressed: (){
                    setState(() {
                      showpass =!showpass;
                    });
                  },
                 icon: Icon(Icons.remove_red_eye,color: Color.fromARGB(255, 116, 26, 1),)):null,
                contentPadding: EdgeInsets.only(bottom: 3),
                labelText: labeltext,
                floatingLabelBehavior: FloatingLabelBehavior.always,
                hintText: x,
                hintStyle: TextStyle(fontSize: 16,
                fontWeight: FontWeight.bold,color: Colors.black)
                ),
            );
  }
}


