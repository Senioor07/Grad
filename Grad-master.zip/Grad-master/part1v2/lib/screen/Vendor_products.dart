import 'package:flutter/material.dart';
import 'package:part1v2/constant/Fertllizers.dart';
import 'package:part1v2/constant/Seeds.dart';
import 'package:part1v2/constant/Tools.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/Add_product.dart';
import 'package:part1v2/screen/edit_product.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/wiidget/drawervendor.dart';

class Vendor_product extends StatefulWidget {
  const Vendor_product({super.key});

  @override
  State<Vendor_product> createState() => _Vendor_productState();
}

class _Vendor_productState extends State<Vendor_product> {
  List<tools> _toolsmarketlist=tools.toolsList;
  List<Plant> _plantmarketlist=Plant.plantList;
  List<fertllizers> _fertllizersmarketlist=fertllizers.fertllizersList;
  List<seeds> _seedsmarketlist=seeds.seedsList;
   int count =4;
  
   void deleteItem(int index) {
    setState(() {
      
      _plantmarketlist.removeAt(index);
     count--;
    });
  }

  @override
  Widget build(BuildContext context) {
   
    return Scaffold(
     // backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      appBar: AppBar(
        
        backgroundColor: Color.fromRGBO(247, 245, 244, 1),
       iconTheme: IconThemeData(color: Color.fromARGB(255, 110, 37, 37)),
        elevation: 0,
        title: Text('My Products',style: TextStyle(color: Colors.black,fontSize: 25,fontWeight: FontWeight.w600),),
        
      ),
     // drawer: drawerVendor(),
      body:  Stack(
        children: [
          Image.asset("assets/16.jpg",fit: BoxFit.cover,width: double.infinity,),
          Padding(
            padding: const EdgeInsets.only(top: 40,left: 5,right: 5),
            child: ListView.builder(
                  itemCount: count,
                  itemBuilder: (BuildContext context, int index) {
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(15.0),
              ),
              elevation:10,
              margin: EdgeInsets.all(8),
              child: ListTile(
                
                leading: CircleAvatar(
                  backgroundColor: Color.fromARGB(200, 100, 50, 1),
                  
                  backgroundImage: AssetImage(_plantmarketlist[index].imageURL2),
                ),
                title: Text(_plantmarketlist[index].plantName2),
                trailing: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(_plantmarketlist[index].price.toString(),style: TextStyle(fontSize: 20),),
                    Text('\$',style: TextStyle(fontSize: 20)),
                    SizedBox(width: 20),
                    IconButton(
                      icon: Icon(Icons.edit),
                      onPressed: () {
                           Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Edit_product(plantidmarket:_plantmarketlist[index].plantId ,)));
                      },
                    ),
                    IconButton(
                      icon: Icon(Icons.delete,color: Colors.red,),
                      onPressed: () {
                        deleteItem(index);
                        //count--;
                      },
                    ),
          
                  ],
                ),
                
              ),
              
              
              
            );
          
                  },
                  
                ),
          ),
      Positioned(
       // top: 5,
        child: IconButton(onPressed: (){
          Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                (context)=>homePage()));
        },
         icon: Icon(Icons.arrow_back)),
      )
      
        ],
      ),
       floatingActionButton:   Container(
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.all(10.0),
                child: ElevatedButton(
                   style: ElevatedButton.styleFrom(
    primary: Colors.green, 
  ),
                  
                  onPressed: () {
                     Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Add_product()));
                  },
                  child: Text('Add Product'),
                ),
              ),
            ),
          ),
          
      
    );
  }
}