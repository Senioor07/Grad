import 'package:flutter/material.dart';
import 'package:part1v2/constant/global_var.dart';
import 'package:part1v2/screen/card.dart';
import 'package:part1v2/screen/stepGrow.dart';

class Shipping extends StatefulWidget {
  const Shipping({super.key});

  @override
  State<Shipping> createState() => _ShippingState();
}

class _ShippingState extends State<Shipping> {
  bool check = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leadingWidth: 20,
        toolbarHeight: 40,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black),
          onPressed: () {
            Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>cardpage()));
          },
        ),
      ),
      body:Stack(
        children: [
          Image.asset("assets/c2.jpg",fit: BoxFit.cover,width: double.infinity,),
           SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 120),
                child: Text(
                  'Shipping',
                  style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
                ),
              ),
              SizedBox(height: 50),
              TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(labelText: 'Your Email'),
              ),
              SizedBox(height: 10,),
              TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(labelText: 'Address'),
              ),
               SizedBox(height: 10,),
              Row(
                children: [
                  Expanded(
                    child: Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: TextField(
                        decoration: InputDecoration(
                          labelText: "City",
                        ),
                      ),
                    ),
                  ),
                  SizedBox(width: 10),
                  SizedBox(
                    width: 150,
                    child: TextField(
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(
                        labelText: "ZIP Code",
                      ),
                    ),
                  ),
                ],
              ),
               SizedBox(height: 10,),
              TextField(
                decoration: InputDecoration(
                  labelText: "Country",
                ),
              ),
               SizedBox(height: 10,),
              Row(
                children: [
                  Expanded(
                    child: TextField(
                      enabled: check,
                      keyboardType: TextInputType.number,
                      decoration: InputDecoration(labelText: 'Credit-debit'),
                    ),
                  ),
                  SizedBox(width: 10),
                  Checkbox(
                    value: check,
                    onChanged: (value) {
                      setState(() {
                        check = value!;
                      });
                    },
                  ),
                ],
              ),
              SizedBox(height: 70),
              Padding(
                padding: const EdgeInsets.only(left: 150),
                child: Container(
                  width: 120,
                  alignment: AlignmentDirectional.bottomCenter,
                  child: TextButton(
                    style: TextButton.styleFrom(
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(30)),
                      backgroundColor: Color.fromARGB(255, 246, 200, 115),
                      minimumSize: const Size.fromHeight(20),
                      
                    ),
                    onPressed: () {
                      // AlertDialog(
                      //   title: Text("Confirmation"),
                      //   content: Text("Are you sure you want to proceed?"),
                      //   actions: []
              
                      // )
                    },
                    child: Text(
                      'Finish',
                      style: TextStyle(
                        fontSize: 24,
                        color: Color.fromARGB(255, 95, 63, 7),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
        ],
      )
    );
  }
}
