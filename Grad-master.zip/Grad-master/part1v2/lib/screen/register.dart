import 'package:flutter/material.dart';
import 'package:part1v2/screen/login.dart';
import 'package:part1v2/constant/global_var.dart';


class registerScreen extends StatefulWidget {
  const registerScreen({super.key});

  @override
  State<registerScreen> createState() => _registerScreenState();
}

class _registerScreenState extends State<registerScreen> {
  bool pass = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            "assets/image7.jpg",
            height: 300,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          SingleChildScrollView(
            child: Container(
              margin: const EdgeInsets.only(top: 250),
              decoration: BoxDecoration(
                color: Color.fromRGBO(248, 225, 213, 1),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(40),
                  topRight: Radius.circular(40),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.all(40.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                  
                        TextField(
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Color.fromARGB(255, 239, 234, 234),
                            hintText: "Full Name",hintStyle: TextStyle(color: Color.fromARGB(255, 1, 4, 1)),
                            prefixIcon: Icon(
                              Icons.person,
                              color: Color.fromRGBO(122, 61, 59, 1)
                            ),
                            border: OutlineInputBorder(
                              
                              borderRadius: BorderRadius.circular(15),

                          ),
                          
                          
                          ) 
                        ),
                         const SizedBox(height:10),
                   
                   
                       
                        TextField(
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Color.fromARGB(255, 239, 234, 234),
                            hintText: "Email",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                            prefixIcon: Icon(
                              Icons.email,
                              color: Color.fromRGBO(122, 61, 59, 1),
                            ),
                              border: OutlineInputBorder(
                              
                               borderRadius: BorderRadius.circular(15),

                          ),
                          ),
                        ),
                        const SizedBox(height:10),
                    
                    
                        TextField(
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: Color.fromARGB(255, 239, 234, 234),
                            hintText: "Password",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Color.fromRGBO(122, 61, 59, 1),
                            ),
                              border: OutlineInputBorder(
                              
                              borderRadius: BorderRadius.circular(15),

                          ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                pass ? Icons.visibility_off : Icons.visibility,
                                color: const Color.fromARGB(255, 1, 2, 1),
                              ),
                              onPressed: () {
                                setState(() {
                                  pass = !pass;
                                });
                              },
                            ),
                          ),
                          obscureText: pass,
                        ),
                        const SizedBox(height: 10),
                    
                    SizedBox(height: 5,),
                        TextField(
                          decoration: InputDecoration(
                          
                            filled: true,
                            fillColor: Color.fromARGB(255, 239, 234, 234),
                            hintText: "Confirm Password",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                            prefixIcon: Icon(
                              Icons.lock,
                              color: Color.fromRGBO(122, 61, 59, 1),
                            ),
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(15),

                          ),
                            suffixIcon: IconButton(
                              icon: Icon(
                                pass ? Icons.visibility_off : Icons.visibility,
                                color: const Color.fromARGB(255, 6, 8, 6),
                              ),
                              onPressed: () {
                                setState(() {
                                  pass = !pass;
                                });
                              },
                            ),
                          ),
                          obscureText: pass,
                        ),
                         Row(
                       //   mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                           
                                 Checkbox(
                                   activeColor: Colors.green,
          value: isChecked,
          onChanged: (bool? value) {
            setState(() {
              isChecked = value ?? false;
            });
          },
        ),
         Text(
                                "Sign Up As Seller",
                                style: TextStyle(
                                  color: Color.fromARGB(255, 183, 54, 48),
                                     fontWeight: FontWeight.bold,
                                ),
                              ),
                              SizedBox(width: 60,),
                       
         
                          
                              
                          ],
                        ),
                        const SizedBox(height:10),
                        Center(
                          child: ElevatedButton(
                           onPressed: () {
                          Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>SignupScreen()));

                           },
                            style: ElevatedButton.styleFrom(
                            primary: Color.fromRGBO(122, 61, 59, 1),
                             shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                                    ),
                             minimumSize: Size(100, 50), //width 
                           maximumSize: Size(200, double.infinity), 
                            ),
                                               child: Row(
                                               mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                          Text(
                               "Sign Up",
                             style: TextStyle(color: Colors.white, fontSize: 19),
                             ),
                              ],
                            ),
                                               ),
                        ),
                      
                        Row(
                          children: [
                            TextButton(
                              onPressed: () {},
                              child: const Text(
                                "Already have an account?",
                                style: TextStyle(
                                  fontSize: 19,
                                  decoration: TextDecoration.underline,decorationColor: Colors.black,
                                  color: Color.fromARGB(255, 12, 14, 12),
                                ),
                              ),
                            ),
                            TextButton(
                              onPressed: () {
                                Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>SignupScreen()));
                              },
                              child: const Text(
                                "log in",
                                style: TextStyle(
                                  fontSize: 19,
                                  
                                  color: Color.fromARGB(255, 32, 71, 84),
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Divider(),
                        
                        
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}