import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import 'package:part1v2/screen/Vendor_products.dart';

class Add_product extends StatefulWidget {
  const Add_product({Key? key}) : super(key: key);

  @override
  State<Add_product> createState() => _Add_productState();
}

class _Add_productState extends State<Add_product> {
  File? _image;
  String? _selectedItem;

  Future getImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.getImage(source: ImageSource.gallery);

    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
      } else {
        print('No image selected.');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      body: SingleChildScrollView(
        child:Stack(
          children: [
            Image.asset("assets/k5.jpg"),
             Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 37),
              child: Expanded(
                flex: 2,
                child: GestureDetector(
                  onTap: () {
                    getImage();
                  },
                  child: Container(
                    padding: EdgeInsets.only(bottom: 30),
                    decoration: BoxDecoration(
                      color: Color.fromARGB(255, 224, 224, 224),
                      borderRadius: BorderRadius.circular(35)
                    ),
                    width: 200,
                    height: 200,
                    child: AspectRatio(
                      aspectRatio: 1,
                      child: _image == null
                          ? Icon(Icons.add_a_photo, size: 100)
                          : Image.file(_image!, fit: BoxFit.cover),
                    ),
                  ),
                ),
              ),
            ),
      
            Padding(padding: 
            EdgeInsets.only(left:15, right: 20.0, top: 20.0),
            child: TextField(
              decoration: InputDecoration(
                hintText: "Enter the name",
                filled: true,
                 fillColor: Color.fromARGB(255, 247, 247, 247),
                 border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                    borderSide: BorderSide.none
                    
                  )
              ),
            ),
            
            
            ),
            SizedBox(height: 15),
            
            Padding(
              padding: const EdgeInsets.only(left: 15,right: 20,top: 2),
              child: DropdownButtonFormField<String>(
                value: _selectedItem,
                items: [
                  DropdownMenuItem(
                    value: 'Plant',
                    child: Text('Plant'),
                  ),
                  DropdownMenuItem(
                    value: 'Seeds',
                    child: Text('Seeds'),
                  ),
                  DropdownMenuItem(
                    value: 'Fertilizers',
                    child: Text('Fertilizers'),
                  ),
                  DropdownMenuItem(
                    value: 'Tools',
                    child: Text('Tools'),
                  ),
                ],
                onChanged: (value) {
                  setState(() {
                    _selectedItem = value;
                  });
                },
                decoration: InputDecoration(
                  hintText: 'Select The type of product',
                  filled: true,
                  fillColor: Color.fromARGB(255, 247, 247, 247),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(25),
                    borderSide: BorderSide.none
                    
                  )
                ),
              ),
            ),
            SizedBox(height: 15),
             Padding(
               padding: const EdgeInsets.only(left: 15,right: 20,top: 2),
               child: TextField(
                              decoration: InputDecoration(
                    hintText: "Price",
                    filled: true,
                     fillColor: Color.fromARGB(255, 247, 247, 247),
                     border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(25),
                        borderSide: BorderSide.none
                        
                      )
                              ),
                            ),
             ),
             SizedBox(height: 15),
           Padding(
             padding: const EdgeInsets.only(left: 15,right: 20,top: 2),
             child: TextField(
                                maxLines: 5,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Color.fromARGB(255, 247, 247, 247),
                                  hintText: "Description",hintStyle: TextStyle(color: const Color.fromARGB(255, 1, 4, 1)),
                                  
                                    border: OutlineInputBorder(
                                    
                                     borderRadius: BorderRadius.circular(20),
                                     borderSide: BorderSide.none
                
                                ),
                                ),
                              ),
           ),
            
      
            Container(
              child: Align(
                alignment: Alignment.bottomCenter,
                child: Padding(
                  padding: const EdgeInsets.all(10.0),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      primary: Colors.green,
                      shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                              
                            ),
                    ),
                    onPressed: () {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => Vendor_product()),
                      );
                      print('Product added!');
                    },
                    
                    child: Text('Add Product'),
                  ),
                ),
              ),
            ),
          ],
        ),
          ],
        )
      ),
    );
  }
}