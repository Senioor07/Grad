import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/dataset/build_plant.dart';
import 'package:part1v2/dataset/plantss.dart';
import 'package:part1v2/screen/detailsplant.dart';

class searchScreenPage extends StatefulWidget {
  const searchScreenPage({Key? key});

  @override
  State<searchScreenPage> createState() => _SearchScreenPageState();
}
///HEX 793d3d
///RGB rgb(121, 61, 61)
enum MenuOption { All,popular, indoor, outdoor, flowers }
MenuOption selectedOption = MenuOption.All;
class _SearchScreenPageState extends State<searchScreenPage> {
  // Buildplaces places=Buildplaces();
  // List<plantss>data=[];
  // _getplantlist()async{
  //   data=await places.buildplaces();

  // }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   _getplantlist();
  //   super.initState();
    
  // }
  
  String searchText = '';
  List<Plant> _plantList = Plant.plantList;
///#f8e1d5
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      
      body: Stack(
        children: [
          Image.asset("assets/k14.jpeg",fit: BoxFit.cover,width: double.infinity),
          SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.only(top: 45),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    padding: EdgeInsets.symmetric(horizontal: 15),
                    width: size.width * .9,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Icon(Icons.search, color: Color.fromRGBO(122, 61, 59, 1).withOpacity(.6)),
                        Expanded(
                          child: TextField(
                            onChanged: (value) {
                              setState(() {
                                searchText = value;
                              });
                            },
                            showCursor: false,
                            decoration: InputDecoration(
                             
                              hintText: "Search Plant",
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              
                            ),
                          ),
                        ),
                       
                        IconButton(
                          onPressed: (){
                            showMenu(
                              context: context,
                               position:  RelativeRect.fromLTRB(100, 80, 0, 0), 
                               items: [
                                PopupMenuItem<MenuOption>(
                               value: MenuOption.popular,
                                 child: Text('All',style: TextStyle(
                                  color: selectedOption
                                  ==MenuOption.All?Colors.brown:null
                                 ),),
                                 
                                  ),
                                PopupMenuItem<MenuOption>(
                               value: MenuOption.popular,
                                 child: Text('Popular',
                                 style: TextStyle(
                                  color: selectedOption
                                  ==MenuOption.popular?Colors.brown:null
                                 ),),
                                  ),
                                   PopupMenuItem<MenuOption>(
                                  value: MenuOption.indoor,
                                  child: Text('Indoor',
                                  style: TextStyle(
                                  color: selectedOption
                                  ==MenuOption.indoor?Colors.brown:null
                                 ),),
                                  ),
                                  PopupMenuItem<MenuOption>(
                                   value: MenuOption.outdoor,
                                 child: Text('Outdoor',
                                 style: TextStyle(
                                  color: selectedOption
                                  ==MenuOption.outdoor?Colors.brown:null
                                 ),),
                                  ),
                                 PopupMenuItem<MenuOption>(
                                 value: MenuOption.flowers,
                               child: Text('Flowers',
                               style: TextStyle(
                                  color: selectedOption
                                  ==MenuOption.flowers?Colors.brown:null
                                 ),),
                                 ),
   ],
                               ).then((value){
                                if (value != null) {
                                setState(() {
                              selectedOption = value;
                              // if (selectedOption != MenuOption.All) {
                              //           _plantList = Plant.plantList.where((plant) =>
                              //               plant.plantName.toLowerCase().contains(searchText.toLowerCase()) &&
                              //               plant.category.toLowerCase() == selectedOption.toString().split('.').last.toLowerCase()).toList();
                              //         } else {
                                        
                              //         }

                               });
                              }
                               } );
                          },
                           icon: Icon(Icons.menu,color: Color.fromRGBO(122, 61, 59, 1),))
                      ],
                    ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(20),
                      
                    ),
                  ),
                ],
              ),
            ),
            SizedBox(height: 30),
            SingleChildScrollView(
              scrollDirection: Axis.vertical,
              child: Column(
                children: _plantList
                
                    .map(
                      (Plant plant) => Visibility(
                        visible: plant.plantName.toLowerCase().contains(searchText.toLowerCase()) ||
                            searchText.isEmpty,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.push(
                              context,
                              PageTransition(
                                child: detailsplantSceen(plantId: plant.plantId),
                                type: PageTransitionType.bottomToTop,
                              ),
                            );
                          },
                          child: Container(
                            width: 370,
                             
                             height: 80,
                            margin: EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                            child: Row(
                              children: [
                                ///imageurl
                                Container(
                                  width: 80,
                                  decoration: BoxDecoration(
                                    color: Colors.white
                                  ),
                                  child: Image.asset(plant.imageURL)),
                              
                              ///plant name
                                Padding(
                                  padding: const EdgeInsets.only(top:25,left: 40),
                                  child: Column(
                                    children: [
                                      Text(
                                    plant.plantName,
                                    style: TextStyle(
                                        color: Color.fromARGB(255, 110, 37, 37), fontSize: 18, fontWeight: FontWeight.bold),
                                  ),
                                      Text(
                                    plant.category,
                                    style: TextStyle(color: Color.fromARGB(255, 110, 37, 37), fontSize: 20),
                                  ),
                                    
                                    ],
                                
                                
                                  ),
                                )

                              ],
                            ),
                     
                            decoration: BoxDecoration(
                             color: Color.fromRGBO(239, 235, 235, 1),
                             //.withOpacity(.9),
                              borderRadius: BorderRadius.circular(20),
                            ),
                          ),
                        ),
                      ),
                    )
                    .toList(),
              ),
            ),
            SizedBox(height: 15),
            
          ],
        ),
      )
        ],
      ),
    );
  }
  
}