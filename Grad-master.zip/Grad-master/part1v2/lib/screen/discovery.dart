import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';
class disAr extends StatefulWidget {
  const disAr({super.key});

  @override
  State<disAr> createState() => _disArState();
}

class _disArState extends State<disAr> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.only(top: 160),
        child: Column(
          children: [
            // Center(
            //   child: Text("ass")
            // ),
            // SizedBox(
            //   width: double.infinity,
            //   height: 400,
            //   child:  WebView(
            //     initialUrl: "https://app.vectary.com/p/2hpNVOcZGMg4wpYCd3b8Ze",
            //     javascriptMode: JavascriptMode.unrestricted,
            //   ),
            // )
          ],
        ),
      ),
    );
  }
}