import 'package:flutter/material.dart';
import 'package:part1v2/constant/plant.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/homeScreen.dart';
import 'package:part1v2/screen/myplantcaredetails.dart';
import 'package:part1v2/screen/plant_widget.dart';

class myplantPageScreen extends StatefulWidget {
  const myplantPageScreen({super.key, required this.growplants});
  final List <Plant>growplants;

  @override
  State<myplantPageScreen> createState() => _myplantPageScreenState();
}

class _myplantPageScreenState extends State<myplantPageScreen> {

  
  @override
  Widget build(BuildContext context) {
    Size size=MediaQuery.of(context).size;
    return Scaffold(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(248, 225, 213, 1),
        elevation: 0,
        title: Text('Myplants',style: TextStyle(color: Colors.black,fontSize: 25,fontWeight: FontWeight.w700),),
        leading:  IconButton(
          onPressed: (){
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
          },
           icon: Icon(Icons.arrow_back_outlined,color:Color.fromARGB(255, 15, 80, 17),)),
      ),
      
       
      body:
       widget.growplants.isEmpty?
      Center(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: 100,
              child: GestureDetector(
                onTap: () {
                   Navigator.pushReplacement(context,MaterialPageRoute(builder:
                                (context)=>plantcareScreen()));
                },
                child: Text("No Plants Yet",style: TextStyle(fontSize: 20),))),
          ],
        ),
      ):
      Container(
        padding: EdgeInsets.symmetric(vertical: 30,horizontal: 12),
        height: size.height*.5,
        child: ListView.builder(
          itemCount: widget.growplants.length,
          scrollDirection: Axis.vertical,
          physics: BouncingScrollPhysics(),
          itemBuilder: (BuildContext context,int index) {
            return plantwidget(index: index, plantList: widget.growplants);
          },),
      ),

    );
  }
}