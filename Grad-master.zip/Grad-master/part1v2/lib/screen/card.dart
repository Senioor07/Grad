import 'package:flutter/material.dart';
import 'package:part1v2/screen/home.dart';
import 'package:part1v2/screen/marketing.dart';
import 'package:part1v2/wiidget/bottomnavcard.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class cardpage extends StatefulWidget {
  const cardpage({super.key});
  @override
  State<cardpage> createState() => _cardpageState();
}

class _cardpageState extends State<cardpage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage("assets/c2.jpg"),
            fit: BoxFit.cover,
          ),
        ),
        child: Stack(
          children: [
           
            Column(
        
          children: [
            SizedBox(height: 40.h,),
            Row(children: [
            IconButton(onPressed: (){
             Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
            }, icon:Icon(Icons.arrow_back)),
            SizedBox(width: 110.w,),
            Text ("MY Card",style: TextStyle(fontSize: 28),)
            ],),
            SizedBox(height: 15.h,),
            Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.only(topRight: Radius.circular(20),
                   bottomRight: Radius.circular(20)),
                   color: Color.fromRGBO(229, 242, 195, 1),
                  ),
                  width: 380.w,
                 height: 110.h,
                 child: Row(
        
                  children: [
                     Container(
                                    width: 80.w,
                                    height: 110.h,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                    ),
                                    child: Image.asset("assets/pro10.png",)),
                                    SizedBox(width: 20.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Flowers",style: TextStyle(
                                            fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromARGB(255, 181, 77, 77)
                                          ),),
                                          SizedBox(height: 20.h,),
                                          Text("50\$",style: TextStyle(
                                            fontSize: 18,fontWeight: FontWeight.w400,color: Color.fromARGB(255, 181, 77, 77)
                                          ),)
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 80.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                       // crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          IconButton(onPressed: (){},
                                        icon:Icon(Icons.delete,color: Colors.red,)),
                                        SizedBox(height: 10.h,),
                                        Container(
                                          width: 70.w,
                                          height: 30.h,
                                          decoration: BoxDecoration(
                                            
                                            color: Color.fromARGB(255, 84, 206, 88),
                                            borderRadius: BorderRadius.circular(20)
                                            
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(Icons.remove,color: Colors.white,),
                                                Text("2",style: TextStyle(
                                                  fontSize: 18,color: Color.fromARGB(255, 181, 77, 77)
                                                ),),
                                                 Icon(Icons.add,color: Colors.white),
                                              ],
                                            ),
                                          ),
        
                                        ),
                                        SizedBox(height: 10.h,),
                                        
        
                                        ],
                                      ),
                                    )            
                                       ],
               
              
            )
                ),
        
                  Container(
                  margin: EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.only(topRight: Radius.circular(20),
                   bottomRight: Radius.circular(20)),
                   color: Color.fromRGBO(229, 242, 195, 1),
                  ),
                  width: 380.w,
                 height: 110.h,
                 child: Row(
        
                  children: [
                     Container(
                                    width: 80.w,
                                    height: 110.h,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                    ),
                                    child: Image.asset("assets/pro3.png",)),
                                    SizedBox(width: 20.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Tldgped",style: TextStyle(
                                            fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromARGB(255, 181, 77, 77)
                                          ),),
                                          SizedBox(height: 20.h,),
                                          Text("40\$",style: TextStyle(
                                            fontSize: 18,fontWeight: FontWeight.w400,color: Color.fromARGB(255, 181, 77, 77)
                                          ),)
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 80.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                       // crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          IconButton(onPressed: (){},
                                        icon:Icon(Icons.delete,color: Colors.red,)),
                                        SizedBox(height: 10.h,),
                                        Container(
                                          width: 70.w,
                                          height: 30.h,
                                          decoration: BoxDecoration(
                                            
                                            color: Color.fromARGB(255, 84, 206, 88),
                                            borderRadius: BorderRadius.circular(20)
                                            
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(Icons.remove,color: Colors.white,),
                                                Text("1",style: TextStyle(
                                                  fontSize: 18,color: Color.fromARGB(255, 181, 77, 77)
                                                ),),
                                                 Icon(Icons.add,color: Colors.white),
                                              ],
                                            ),
                                          ),
        
                                        ),
                                        SizedBox(height: 10.h,),
                                        
        
                                        ],
                                      ),
                                    )                                                       
                                       ],
            )
                ),
                               Container(
                  margin: EdgeInsets.symmetric(vertical: 7, horizontal: 15),
                  decoration: BoxDecoration(
                   borderRadius: BorderRadius.only(topRight: Radius.circular(20),
                   bottomRight: Radius.circular(20)),
                   color: Color.fromRGBO(229, 242, 195, 1),
                  ),
                  width: 380.w,
                 height: 110.h,
                 child: Row(
        
                  children: [
                     Container(
                                    width: 80.w,
                                    height: 110.h,
                                    decoration: BoxDecoration(
                                      color: Colors.white
                                    ),
                                    child: Image.asset("assets/pro4.png",)),
                                    SizedBox(width: 20.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 20),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text("Florimp",style: TextStyle(
                                            fontSize: 20,fontWeight: FontWeight.w500,color: Color.fromARGB(255, 181, 77, 77)
                                          ),),
                                          SizedBox(height: 20.h,),
                                          Text("60\$",style: TextStyle(
                                            fontSize: 18,fontWeight: FontWeight.w400,color: Color.fromARGB(255, 181, 77, 77)
                                          ),)
                                        ],
                                      ),
                                    ),
                                    SizedBox(width: 80.w,),
                                    Padding(
                                      padding: const EdgeInsets.only(top: 5),
                                      child: Column(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                       // crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          IconButton(onPressed: (){},
                                        icon:Icon(Icons.delete,color: Colors.red,)),
                                        SizedBox(height: 10.h,),
                                        Container(
                                          width: 70.w,
                                          height: 30.h,
                                          decoration: BoxDecoration(
                                            
                                            color: Color.fromARGB(255, 84, 206, 88),
                                            borderRadius: BorderRadius.circular(20)
                                            
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.all(4.0),
                                            child: Row(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(Icons.remove,color: Colors.white,),
                                                Text("3",style: TextStyle(
                                                  fontSize: 18,color: Color.fromARGB(255, 181, 77, 77)
                                                ),),
                                                 Icon(Icons.add,color: Colors.white),
                                              ],
                                            ),
                                          ),
        
                                        ),
                                        SizedBox(height: 10.h,),
                                        
        
                                        ],
                                      ),
                                    )                 
                                                   
                                       ],
               
              
            )
                ),
                ]
                ),
                SizedBox(height: 60.h,), 
                
          ],
        )
        
        
          ],
        ),
        
      ),
      bottomNavigationBar: bottomnaviCard(),
    );
  }
}