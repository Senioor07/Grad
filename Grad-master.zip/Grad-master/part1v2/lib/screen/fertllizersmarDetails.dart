import 'package:flutter/material.dart';
import 'package:part1v2/constant/Fertllizers.dart';
import 'package:part1v2/screen/home.dart';

import 'package:part1v2/screen/marketScreen.dart';
import 'package:part1v2/screen/fertllizersmarket.dart';
import 'package:part1v2/screen/marketing.dart';

class fertllizersmarDetails extends StatefulWidget {
  const fertllizersmarDetails({super.key, required this.fertllizersidmarket});
  final int fertllizersidmarket;
  @override
  State<fertllizersmarDetails> createState() => _fertllizersmarDetailsState();
}

class _fertllizersmarDetailsState extends State<fertllizersmarDetails> {
   List<fertllizers> _fertllizersmarketlist=fertllizers.fertllizersList;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
     return Scaffold(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      body: Stack(children: [
        Container(
          padding: EdgeInsets.all(8),
          margin: EdgeInsets.only(top:320,left: 10,right: 10,bottom: 10),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
            color: Color.fromARGB(166, 22, 107, 25),
            
          ),
          
        ),
         Positioned(
          top:100,left: 100,
          child: Container(width: 210,height: 190,
                        decoration: BoxDecoration(
                          border: Border.all(
                            width: 4,
                            color: Theme.of(context).scaffoldBackgroundColor,
                          ),
                          boxShadow:[ BoxShadow(
                            spreadRadius: 2,blurRadius: 10,
                            color: Colors.black.withOpacity(.1),
                            offset: Offset(0, 10)
                          ),],
                          shape: BoxShape.circle,
                          image: DecorationImage(image:
                           AssetImage(_fertllizersmarketlist[widget.fertllizersidmarket].imageURL),fit:BoxFit.cover)
                        ),),
        ),
          Positioned(
            top:30,
            child: IconButton(onPressed:(){
             Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
            },
              icon: Icon(Icons.arrow_back_ios_new))),

           
 Positioned(
        bottom: 300,left: 30,
        child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].fertllizersName}",
        style: TextStyle(fontSize: 35,color: Color.fromARGB(255, 200, 224, 201)),)),
        Positioned(
        bottom: 300,right: 30,
        child: Container(
          padding: EdgeInsets.all(10),
         decoration: BoxDecoration(
           color: Color.fromARGB(235, 101, 214, 105),
           borderRadius: BorderRadius.only(topRight: Radius.circular(15),bottomLeft: Radius.circular(15))
         ),
          child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].price}\$",
          style: TextStyle(fontSize: 20,color: Color.fromARGB(255, 213, 230, 214)),),

        )),
        Positioned(
        
        bottom: 200,left: 30,
        child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].decription}",
        style: TextStyle(fontSize:18,color: Color.fromARGB(255, 200, 224, 201)),)),
         Positioned(
        
        bottom: 170,left: 30,
        child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].category}",
        style: TextStyle(fontSize:18,color: Color.fromARGB(255, 200, 224, 201)),)),
        Positioned(
          bottom: 60,left:30 ,
          child: ElevatedButton(
                            onPressed: () {
                               Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Color.fromARGB(159, 3, 92, 6),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(20),
                                
                              ),
                                minimumSize: Size(100, 50), //width 
                             maximumSize: Size(150, double.infinity), 
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                               
                                const Text(
                                  "Add To Card",
                                  style: TextStyle(color: Colors.white),
                                ),
                              ],
                            ),
                          ),
        ),    
                Positioned(
          bottom: 22,right: 30 ,
          child: 
           Padding(
                                    padding: const EdgeInsets.symmetric(vertical: 30),
                                    child: Container(
                                          padding: EdgeInsets.all(10),
                                          
                                          decoration: BoxDecoration(
                                            
                                            color: Color.fromARGB(235, 101, 214, 105),
                                            borderRadius: BorderRadius.circular(20)
                                            
                                          ),
                                          
                                            
                                            child: Column(
                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                              children: [
                                                Icon(Icons.remove,color: Colors.white,),
                                                Text("0",style: TextStyle(
                                                  fontSize: 18,color: Color.fromARGB(255, 181, 77, 77)
                                                ),),
                                                 Icon(Icons.add,color: Colors.white),
                                              ],
                                            ),
                                          
                                                              
                                        ),
                                  )
        ),

        


      ],)

    );
  }
}



//  Positioned(
//         bottom: 130,left: 30,
//         child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].fertllizersName}",
//         style: TextStyle(fontSize: 30,color: const Color.fromARGB(255, 84, 152, 87)),)),
//         Positioned(
//         bottom: 100,right: 30,
//         child: Text("${_fertllizersmarketlist[widget.fertllizersidmarket].price}\$",
//         style: TextStyle(fontSize: 20,color: Color.fromARGB(255, 84, 152, 87)),)),
//         Positioned(
//           bottom: 40,right: 30,
//           child: ElevatedButton(
//             onPressed: (){},
          