import 'dart:async';

import 'package:flutter/material.dart';
import 'package:part1v2/screen/login.dart';

class StartScreen extends StatefulWidget {
  const StartScreen({Key? key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  final PageController _pageController = PageController(initialPage: 0);
  int currentIndex = 0;
  @override
  void initState() {
    // TODO: implement initState
    Timer.periodic(Duration(seconds: 4), (timer) { 

      if (currentIndex <2) {
        currentIndex++;
        _pageController.animateToPage(currentIndex, duration: Duration(milliseconds: 300), curve: Curves.easeIn);}
        
    });
      }
     //myscr
      
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.0,
        backgroundColor: Colors.white,
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20, top: 20),
            child: InkWell(
              onTap: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => SignupScreen()),
                );
              },
              child: Text(
                'skip',
                style: TextStyle(
                  color: Colors.grey,
                  fontSize: 16,
                  fontWeight: FontWeight.w400,
                ),
              ),
            ),
          ),
        ],
      ),
      body: Stack(
        alignment: Alignment.bottomCenter,
        children: [
          PageView(
            controller: _pageController,
            onPageChanged: (int page) {
              setState(() {
                currentIndex = page;
                
              });
            },
            children: [
              CreateImage(
                image: 'assets/girl.jpg',
                title: 'Welcome to Planter',
                description: 'Learn how to care for plants',
              ),
              CreateImage(
                image: 'assets/pic5.jpg',
                title: 'Plant a tree, green the earth',
                description: 'Find almost all types of plants',
              ),
              CreateImage(
                image: 'assets/pic2.jpg',
                title: 'Learn more about plants',
                description: 'looking for a beautiful plant ',
              ),
            ],
          ),
          Positioned(
            bottom: 70,
            left: 30,
            child: Row(
              children: _buildIndicator(),
            ),
          ),
          Positioned(
            bottom: 40,
            right: 30,
            child: Container(
              child: IconButton(
                onPressed: () {
                  setState(() {
                    if (currentIndex < 2) {
                      currentIndex++;
                      if (currentIndex < 3) {
                        _pageController.nextPage(
                          duration: Duration(milliseconds: 3000),
                          curve: Curves.easeIn,
                        );
                      }
                    } else {
                      Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (context) => SignupScreen()),
                      );
                    }
                  });
                },
                icon: Icon(Icons.arrow_forward_ios, size: 24, color: Colors.white),
              ),
              padding: EdgeInsets.all(4),
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: Colors.green,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _indicator(bool isActive) {
    return AnimatedContainer(

      duration: Duration(milliseconds: 300),
      height: 10,
      width: isActive ? 20 : 8,
      margin: EdgeInsets.only(right: 5),
      decoration: BoxDecoration(
        color: Colors.green,
        borderRadius: BorderRadius.circular(5),
      ),
    );
  }

  List<Widget> _buildIndicator() {
    List<Widget> indicators = [];

    for (int i = 0; i < 3; i++) {
      if (currentIndex == i) {
        indicators.add(_indicator(true));
      } else {
        indicators.add(_indicator(false));
      }
    }

    return indicators;
  }
}

class CreateImage extends StatelessWidget {
  final String image;
  final String title;
  final String description;

  const CreateImage({
    Key? key,
    required this.image,
    required this.title,
    required this.description,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 50, right: 50, bottom: 80),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 350,
            width: double.infinity,
            child: Image.asset(image),
          ),
          SizedBox(height: 20),
          Text(
            title,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.green, fontSize: 30, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 20),
          Text(
            description,
            textAlign: TextAlign.center,
            style: TextStyle(color: Colors.green, fontSize: 20, fontWeight: FontWeight.w400),
          ),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}