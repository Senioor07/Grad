import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:part1v2/screen/home.dart';
class TakePictureScreen extends StatefulWidget {
  @override
  _TakePictureScreenState createState() => _TakePictureScreenState();
}

class _TakePictureScreenState extends State<TakePictureScreen> {
  late CameraController _controller;
  late Future<void> _initializeControllerFuture = Future<void>.delayed(Duration(seconds: 1));

  @override
  void initState() {
    super.initState();
    _initializeCamera();
  }

  Future<void> _initializeCamera() async {
    final cameras = await availableCameras();
    final firstCamera = cameras.first;

    _controller = CameraController(
      firstCamera,
      ResolutionPreset.medium,
    );

    await _controller.initialize();

    if (mounted) {
      setState(() {
        _initializeControllerFuture = Future.value();
      });
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color.fromRGBO(248, 225, 213, 1),
      appBar: AppBar(
        backgroundColor: Color.fromRGBO(248, 225, 213, 1),
        elevation: 0,
        title: Padding(
          padding: const EdgeInsets.only(left: 95),
          child: Text('Scan',style: TextStyle(color: Colors.black,fontSize: 30,),),
        ),
        leading:  IconButton(
          onPressed: (){
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
          },
           icon: Icon(Icons.arrow_back_outlined,color:Color.fromARGB(255, 15, 80, 17),)),
      ),

      body: Column(
        children: [
         
       Padding(
         padding: const EdgeInsets.all(20.0),
         child: ClipRRect(
          
          borderRadius: BorderRadius.circular(20.0),
          child :SizedBox(
           width: double.infinity,
            height: 500,
          child: FutureBuilder<void>(
               future: _initializeControllerFuture,
                 builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.done) {
                return CameraPreview(_controller);
              } else {
                return Center(child: CircularProgressIndicator());
              }
            },
          ),
           
             ), 
         ),
       ),
      
         ElevatedButton(
          
      
          onPressed: () async {
            
            try {
              final image = await _controller.takePicture();
              Navigator.pop(context, File(image.path));
            } catch (e) {
              print(e);
            }
          },
          style: ElevatedButton.styleFrom(
    primary: Color.fromARGB(255, 110, 37, 37), // Change the background color here
  ),
          
                 child:  Text('More Info', ),
        ),
       
       ],
      ),
        
      
    );
  }
}