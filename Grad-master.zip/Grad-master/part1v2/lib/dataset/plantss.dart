// ignore_for_file: public_member_api_docs, sort_constructors_first
// import 'dart:convert';


// class plantss {
//   String name;
//   String title;
  
//   plantss(this.name,this.title);
  

//   plantss.fromjson(Map<String,dynamic>json);

 
// }
// class Note {
//   String title;
//   String text;
//   Note(
//      this.title,
//     this.text,
//   );
//   Note.fromJson(Map <String, dynamic> json){
//     title= json['title'];
//     text = json['text'];
//   }
// }
