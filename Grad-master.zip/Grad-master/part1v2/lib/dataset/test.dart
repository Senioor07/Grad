import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:part1v2/dataset/build_plant.dart';
import 'package:part1v2/dataset/plantss.dart';

class test extends StatefulWidget {
  const test({super.key});

  @override
  State<test> createState() => _testState();
}

class _testState extends State<test> {
  // Buildplaces places=Buildplaces();
  // List<plantss>data=[];
  // _getplantlist()async{
  //   data=await places.buildplaces();

  // }
  // @override
  // void initState() {
  //   // TODO: implement initState
  //   _getplantlist();
  //   super.initState();
    
  // }
 
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("app"),),

body:ListView.builder(itemBuilder: (context, index) {
  return Card(
    child: Padding(
      padding: EdgeInsets.all(16),
      child: Column(
        children: <Widget>[
          Text("text1",style: TextStyle(fontSize: 22),),
          Text("text1")
        ],
      ),
      ),
  );
  
   
},
    ));
  }
}