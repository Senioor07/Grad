import 'package:part1v2/dataset/networking.dart';
import 'package:part1v2/dataset/plantss.dart';

// class Buildplaces{

//   buildplaces() async {
//     networkHelper networkHelpe=networkHelper(Uri.parse('https://perenual.com/api/species-list?key=sk-FzvN657c91a32f2be3477'));

//     var plantsdata= await networkHelpe.getData();
//     var plantslist=plantsdata['data'];
//     List<plantss> result=[];
//     for(var plan in plantslist){
//       result.add(plantss(plan['name']));
//     }
//       return result;
    

//   }
// }