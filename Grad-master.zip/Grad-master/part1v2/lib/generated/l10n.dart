// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars
// ignore_for_file: join_return_with_assignment, prefer_final_in_for_each
// ignore_for_file: avoid_redundant_argument_values, avoid_escaping_inner_quotes

class S {
  S();

  static S? _current;

  static S get current {
    assert(_current != null,
        'No instance of S was loaded. Try to initialize the S delegate before accessing S.current.');
    return _current!;
  }

  static const AppLocalizationDelegate delegate = AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false)
        ? locale.languageCode
        : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      final instance = S();
      S._current = instance;

      return instance;
    });
  }

  static S of(BuildContext context) {
    final instance = S.maybeOf(context);
    assert(instance != null,
        'No instance of S present in the widget tree. Did you add S.delegate in localizationsDelegates?');
    return instance!;
  }

  static S? maybeOf(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Setting`
  String get title {
    return Intl.message(
      'Setting',
      name: 'title',
      desc: '',
      args: [],
    );
  }

  /// `Account`
  String get account {
    return Intl.message(
      'Account',
      name: 'account',
      desc: '',
      args: [],
    );
  }

  /// `Edit Profile`
  String get edit_profile {
    return Intl.message(
      'Edit Profile',
      name: 'edit_profile',
      desc: '',
      args: [],
    );
  }

  /// `Language`
  String get language {
    return Intl.message(
      'Language',
      name: 'language',
      desc: '',
      args: [],
    );
  }

  /// `Dark Mode`
  String get dar_mode {
    return Intl.message(
      'Dark Mode',
      name: 'dar_mode',
      desc: '',
      args: [],
    );
  }

  /// `Notification`
  String get notification {
    return Intl.message(
      'Notification',
      name: 'notification',
      desc: '',
      args: [],
    );
  }

  /// `New for you`
  String get new_for_you {
    return Intl.message(
      'New for you',
      name: 'new_for_you',
      desc: '',
      args: [],
    );
  }

  /// `My Plants`
  String get my_plants {
    return Intl.message(
      'My Plants',
      name: 'my_plants',
      desc: '',
      args: [],
    );
  }

  /// `Gadgets`
  String get gadgets {
    return Intl.message(
      'Gadgets',
      name: 'gadgets',
      desc: '',
      args: [],
    );
  }

  /// `Discovery`
  String get discovery {
    return Intl.message(
      'Discovery',
      name: 'discovery',
      desc: '',
      args: [],
    );
  }

  /// `Gadgets`
  String get title_gadgets {
    return Intl.message(
      'Gadgets',
      name: 'title_gadgets',
      desc: '',
      args: [],
    );
  }

  /// `Soil Moisture`
  String get soil_moisture {
    return Intl.message(
      'Soil Moisture',
      name: 'soil_moisture',
      desc: '',
      args: [],
    );
  }

  /// `temperature : 28`
  String get temperature {
    return Intl.message(
      'temperature : 28',
      name: 'temperature',
      desc: '',
      args: [],
    );
  }

  /// `Rain Sensor`
  String get rain_sesor {
    return Intl.message(
      'Rain Sensor',
      name: 'rain_sesor',
      desc: '',
      args: [],
    );
  }

  /// `Faucet`
  String get faucet {
    return Intl.message(
      'Faucet',
      name: 'faucet',
      desc: '',
      args: [],
    );
  }

  /// `Soba Controller`
  String get soba_controller {
    return Intl.message(
      'Soba Controller',
      name: 'soba_controller',
      desc: '',
      args: [],
    );
  }

  /// `Full Name`
  String get FullName {
    return Intl.message(
      'Full Name',
      name: 'FullName',
      desc: '',
      args: [],
    );
  }

  /// `fatma`
  String get fatma {
    return Intl.message(
      'fatma',
      name: 'fatma',
      desc: '',
      args: [],
    );
  }

  /// `E-mail`
  String get Email {
    return Intl.message(
      'E-mail',
      name: 'Email',
      desc: '',
      args: [],
    );
  }

  /// `fatma@gmail.com`
  String get fatmagmail {
    return Intl.message(
      'fatma@gmail.com',
      name: 'fatmagmail',
      desc: '',
      args: [],
    );
  }

  /// `password`
  String get password {
    return Intl.message(
      'password',
      name: 'password',
      desc: '',
      args: [],
    );
  }

  /// `********`
  String get secret {
    return Intl.message(
      '********',
      name: 'secret',
      desc: '',
      args: [],
    );
  }

  /// `Gender`
  String get Gender {
    return Intl.message(
      'Gender',
      name: 'Gender',
      desc: '',
      args: [],
    );
  }

  /// `Female`
  String get Female {
    return Intl.message(
      'Female',
      name: 'Female',
      desc: '',
      args: [],
    );
  }

  /// `Male`
  String get Male {
    return Intl.message(
      'Male',
      name: 'Male',
      desc: '',
      args: [],
    );
  }

  /// `SAVE`
  String get SAVE {
    return Intl.message(
      'SAVE',
      name: 'SAVE',
      desc: '',
      args: [],
    );
  }

  /// `Edit Profile`
  String get EditProfile {
    return Intl.message(
      'Edit Profile',
      name: 'EditProfile',
      desc: '',
      args: [],
    );
  }

  /// `sansevera`
  String get sansevera {
    return Intl.message(
      'sansevera',
      name: 'sansevera',
      desc: '',
      args: [],
    );
  }

  /// `Origin : Africa`
  String get Origin {
    return Intl.message(
      'Origin : Africa',
      name: 'Origin',
      desc: '',
      args: [],
    );
  }

  /// `Soil : Black`
  String get Soil {
    return Intl.message(
      'Soil : Black',
      name: 'Soil',
      desc: '',
      args: [],
    );
  }

  /// `Light : Low`
  String get Light {
    return Intl.message(
      'Light : Low',
      name: 'Light',
      desc: '',
      args: [],
    );
  }

  /// `Humdity : 34`
  String get Humdity {
    return Intl.message(
      'Humdity : 34',
      name: 'Humdity',
      desc: '',
      args: [],
    );
  }

  /// `Care difficulty : Hard`
  String get Caredifficulty {
    return Intl.message(
      'Care difficulty : Hard',
      name: 'Caredifficulty',
      desc: '',
      args: [],
    );
  }

  /// `Watering : 10-15 days`
  String get Watering {
    return Intl.message(
      'Watering : 10-15 days',
      name: 'Watering',
      desc: '',
      args: [],
    );
  }

  /// `fertilizer :ufine`
  String get fertilizer {
    return Intl.message(
      'fertilizer :ufine',
      name: 'fertilizer',
      desc: '',
      args: [],
    );
  }

  /// `Planting Date : 24/10/2023`
  String get PlantingDate {
    return Intl.message(
      'Planting Date : 24/10/2023',
      name: 'PlantingDate',
      desc: '',
      args: [],
    );
  }

  /// `Last Watering : 30/11/2023`
  String get LastWatering {
    return Intl.message(
      'Last Watering : 30/11/2023',
      name: 'LastWatering',
      desc: '',
      args: [],
    );
  }

  /// `Next Watering : 15/12/2023`
  String get NextWatering {
    return Intl.message(
      'Next Watering : 15/12/2023',
      name: 'NextWatering',
      desc: '',
      args: [],
    );
  }

  /// `Health :`
  String get Health {
    return Intl.message(
      'Health :',
      name: 'Health',
      desc: '',
      args: [],
    );
  }

  /// `Home`
  String get home {
    return Intl.message(
      'Home',
      name: 'home',
      desc: '',
      args: [],
    );
  }

  /// `Setting`
  String get setting {
    return Intl.message(
      'Setting',
      name: 'setting',
      desc: '',
      args: [],
    );
  }

  /// `Contact Us`
  String get contact_us {
    return Intl.message(
      'Contact Us',
      name: 'contact_us',
      desc: '',
      args: [],
    );
  }

  /// `LOG OUT`
  String get log_out {
    return Intl.message(
      'LOG OUT',
      name: 'log_out',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'ar'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    for (var supportedLocale in supportedLocales) {
      if (supportedLocale.languageCode == locale.languageCode) {
        return true;
      }
    }
    return false;
  }
}
