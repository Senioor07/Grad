// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "Caredifficulty":
            MessageLookupByLibrary.simpleMessage("Care difficulty : Hard"),
        "EditProfile": MessageLookupByLibrary.simpleMessage("Edit Profile"),
        "Email": MessageLookupByLibrary.simpleMessage("E-mail"),
        "Female": MessageLookupByLibrary.simpleMessage("Female"),
        "FullName": MessageLookupByLibrary.simpleMessage("Full Name"),
        "Gender": MessageLookupByLibrary.simpleMessage("Gender"),
        "Health": MessageLookupByLibrary.simpleMessage("Health :"),
        "Humdity": MessageLookupByLibrary.simpleMessage("Humdity : 34"),
        "LastWatering":
            MessageLookupByLibrary.simpleMessage("Last Watering : 30/11/2023"),
        "Light": MessageLookupByLibrary.simpleMessage("Light : Low"),
        "Male": MessageLookupByLibrary.simpleMessage("Male"),
        "NextWatering":
            MessageLookupByLibrary.simpleMessage("Next Watering : 15/12/2023"),
        "Origin": MessageLookupByLibrary.simpleMessage("Origin : Africa"),
        "PlantingDate":
            MessageLookupByLibrary.simpleMessage("Planting Date : 24/10/2023"),
        "SAVE": MessageLookupByLibrary.simpleMessage("SAVE"),
        "Soil": MessageLookupByLibrary.simpleMessage("Soil : Black"),
        "Watering":
            MessageLookupByLibrary.simpleMessage("Watering : 10-15 days"),
        "account": MessageLookupByLibrary.simpleMessage("Account"),
        "contact_us": MessageLookupByLibrary.simpleMessage("Contact Us"),
        "dar_mode": MessageLookupByLibrary.simpleMessage("Dark Mode"),
        "discovery": MessageLookupByLibrary.simpleMessage("Discovery"),
        "edit_profile": MessageLookupByLibrary.simpleMessage("Edit Profile"),
        "fatma": MessageLookupByLibrary.simpleMessage("fatma"),
        "fatmagmail": MessageLookupByLibrary.simpleMessage("fatma@gmail.com"),
        "faucet": MessageLookupByLibrary.simpleMessage("Faucet"),
        "fertilizer": MessageLookupByLibrary.simpleMessage("fertilizer :ufine"),
        "gadgets": MessageLookupByLibrary.simpleMessage("Gadgets"),
        "home": MessageLookupByLibrary.simpleMessage("Home"),
        "language": MessageLookupByLibrary.simpleMessage("Language"),
        "log_out": MessageLookupByLibrary.simpleMessage("LOG OUT"),
        "my_plants": MessageLookupByLibrary.simpleMessage("My Plants"),
        "new_for_you": MessageLookupByLibrary.simpleMessage("New for you"),
        "notification": MessageLookupByLibrary.simpleMessage("Notification"),
        "password": MessageLookupByLibrary.simpleMessage("password"),
        "rain_sesor": MessageLookupByLibrary.simpleMessage("Rain Sensor"),
        "sansevera": MessageLookupByLibrary.simpleMessage("sansevera"),
        "secret": MessageLookupByLibrary.simpleMessage("********"),
        "setting": MessageLookupByLibrary.simpleMessage("Setting"),
        "soba_controller":
            MessageLookupByLibrary.simpleMessage("Soba Controller"),
        "soil_moisture": MessageLookupByLibrary.simpleMessage("Soil Moisture"),
        "temperature": MessageLookupByLibrary.simpleMessage("temperature : 28"),
        "title": MessageLookupByLibrary.simpleMessage("Setting"),
        "title_gadgets": MessageLookupByLibrary.simpleMessage("Gadgets")
      };
}
