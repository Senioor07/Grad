// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ar locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names, avoid_escaping_inner_quotes
// ignore_for_file:unnecessary_string_interpolations, unnecessary_string_escapes

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'ar';

  final messages = _notInlinedMessages(_notInlinedMessages);
  static Map<String, Function> _notInlinedMessages(_) => <String, Function>{
        "Caredifficulty": MessageLookupByLibrary.simpleMessage("الرعايه:دائما"),
        "EditProfile": MessageLookupByLibrary.simpleMessage("تعديل البروفايل"),
        "Email": MessageLookupByLibrary.simpleMessage("الايميل"),
        "Female": MessageLookupByLibrary.simpleMessage("انثي"),
        "FullName": MessageLookupByLibrary.simpleMessage("الاسم بالكامل"),
        "Gender": MessageLookupByLibrary.simpleMessage("النوع"),
        "Health": MessageLookupByLibrary.simpleMessage("  سليم  "),
        "Humdity": MessageLookupByLibrary.simpleMessage("الرطوبه : 34"),
        "LastWatering":
            MessageLookupByLibrary.simpleMessage("اخر عمليه ري : 30/11/2023"),
        "Light": MessageLookupByLibrary.simpleMessage("الضوء : قليل"),
        "Male": MessageLookupByLibrary.simpleMessage("ذكر"),
        "NextWatering": MessageLookupByLibrary.simpleMessage(
            "عمليه الري القادمه : 15/12/2023"),
        "Origin": MessageLookupByLibrary.simpleMessage("الاصل : افريقي"),
        "PlantingDate":
            MessageLookupByLibrary.simpleMessage("تاريخ الزراعه : 24/10/2023"),
        "SAVE": MessageLookupByLibrary.simpleMessage("حفظ"),
        "Soil": MessageLookupByLibrary.simpleMessage("التربه : طينيه"),
        "Watering":
            MessageLookupByLibrary.simpleMessage("يروي كل  :10-15 يوم "),
        "account": MessageLookupByLibrary.simpleMessage("الحساب"),
        "contact_us": MessageLookupByLibrary.simpleMessage("تواصل معنا"),
        "dar_mode": MessageLookupByLibrary.simpleMessage("الوضع المظلم"),
        "discovery": MessageLookupByLibrary.simpleMessage("اكتشاف"),
        "edit_profile":
            MessageLookupByLibrary.simpleMessage("تعديل الملف الشخصي"),
        "fatma": MessageLookupByLibrary.simpleMessage("فاطمه"),
        "fatmagmail": MessageLookupByLibrary.simpleMessage("fatma@gmail.com"),
        "faucet": MessageLookupByLibrary.simpleMessage("الصنبور"),
        "fertilizer": MessageLookupByLibrary.simpleMessage("السماد:يوفين"),
        "gadgets": MessageLookupByLibrary.simpleMessage("الأدوات"),
        "home": MessageLookupByLibrary.simpleMessage("الرئيسيه"),
        "language": MessageLookupByLibrary.simpleMessage("اللغه"),
        "log_out": MessageLookupByLibrary.simpleMessage("تسجيل الخروج"),
        "my_plants": MessageLookupByLibrary.simpleMessage("نباتاتي"),
        "new_for_you": MessageLookupByLibrary.simpleMessage("أخر التحديثات"),
        "notification": MessageLookupByLibrary.simpleMessage("الأشعارات"),
        "password": MessageLookupByLibrary.simpleMessage("الباسورد"),
        "rain_sesor": MessageLookupByLibrary.simpleMessage("حساس المطر"),
        "sansevera": MessageLookupByLibrary.simpleMessage("ذلب ثلاثي الأحزمة"),
        "secret": MessageLookupByLibrary.simpleMessage("********"),
        "setting": MessageLookupByLibrary.simpleMessage("الأعدادات"),
        "soba_controller":
            MessageLookupByLibrary.simpleMessage("التحكم في الصوبا"),
        "soil_moisture": MessageLookupByLibrary.simpleMessage("نسبة الرطوبة"),
        "temperature":
            MessageLookupByLibrary.simpleMessage("درجه الحراره : 28"),
        "title": MessageLookupByLibrary.simpleMessage("الاعدادات"),
        "title_gadgets": MessageLookupByLibrary.simpleMessage("الأدوات")
      };
}
