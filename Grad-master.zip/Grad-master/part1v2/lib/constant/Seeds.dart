class seeds {
  final int seedsId;
  final int price;
  
  final double rating;
  final int humidity;
  final String temperature;
  final String category;
  final String seedsName;
  final String imageURL;

  bool isFavorated;
  final String decription;

  bool isSelected;

  seeds(
      {

        required this.seedsId,
        required this.price,
        required this.category,
        required this.seedsName,

        required this.rating,
        required this.humidity,
        required this.temperature,
        required this.imageURL,
        required this.isFavorated,
        required this.decription,
        required this.isSelected});

  //List of seedss data
  static List<seeds> seedsList = [
    seeds(

        seedsId: 0,
        price: 22,
        category: 'Indoor',
        seedsName: 'Sanseviera',

        rating: 4.5,
        isFavorated:true,
        humidity: 34,
        temperature: '23 - 34',
        imageURL: 'assets/pro32.png',
        decription:
        'This seeds is one of the best seeds.It grows'
         'in most of the regions in the world and can survive'
            ' even the harshest weather condition.',
        isSelected: false, 
         ),
    seeds(
      
        seedsId: 1,
        price: 11,
        category: '',
        seedsName: 'Fr arugula',

         isFavorated:true,
        rating: 4.8,
        humidity: 56,
        temperature: '19 - 22',
        imageURL: 'assets/pro21.png',
        decription:
        'this seeds is very A beautiful seeds that needs sunlight daily',
        isSelected: false,),
    seeds(
        seedsId: 2,
        price: 18,
        category: 'Indoor',
        seedsName: 'Beacha',

        rating: 4.7,
        humidity: 34,
        temperature: '22 - 25',
        imageURL: 'assets/pro22.png',
         isFavorated:true,
        decription:
        'Very sweet and useful. It is preferred to be inside the house and does not need to be quenched except every now and then',
        isSelected: false, ),
    seeds(
        seedsId: 3,
        price: 30,
        category: 'Outdoor', ////
        seedsName: 'Pottedg',
      

        rating: 4.5,
        humidity: 35,
        temperature: '23 - 28',
        imageURL: 'assets/pro23.png',
         isFavorated:true,
        decription:
        'It is considered a sofa that brings joy and happiness.',
        isSelected: false, ),
    seeds(
        seedsId: 4,
        price: 24,
        category: 'Flowers',///
        seedsName: 'Goldeow',

        rating: 4.1,
        humidity: 66,
        temperature: '12 - 16',
        imageURL: 'assets/pro24.png',
         isFavorated:true,
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, ),
    seeds(
        seedsId: 5,
        price: 24,
        category: 'Popular',
        seedsName: 'Meadage',
        rating: 4.4,
        humidity: 36,
        temperature: '15 - 18',
        imageURL: 'assets/pro25.png',
         isFavorated:true,
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,  ),
    seeds(
        seedsId: 6,
        price: 19,///
        category: 'Garden',
        seedsName: 'yelsmi',

        rating: 4.2,
        humidity: 46,
        temperature: '23 - 26',
        imageURL: 'assets/pro26.png',
         isFavorated:true,
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, ),
    seeds(
        seedsId: 7,
        price: 23,
        category: 'recommended',///
        seedsName: 'Tritonia',
        rating: 4.5,
        humidity: 34,
         isFavorated:true,
        temperature: '21 - 24',
        imageURL: 'assets/pro27.png',
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,),
    seeds(
        seedsId: 8,
        price: 46,
        category: 'Flowers',
        seedsName: 'uniquse',

        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pro30.png',
         isFavorated:true,
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,),
         seeds(
        seedsId: 9,
        price: 46,
        category: 'Popular',
        seedsName: 'urose',

        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pro31.png',

         isFavorated:true,
        decription:
        'This seeds is one of the best seeds. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,  ),
  ];

  //Get the grow items
  static List<seeds> getgrowseedss(){
    List<seeds> _glList = seeds.seedsList;
    return _glList.where((element) => element.isSelected == true).toList();
  }

  // //Get the cart items
  // static List<seeds> addedToCartseedss(){
  //   List<seeds> _selectedseedss = seeds.seedsList;
  //   return _selectedseedss.where((element) => element.isSelected == true).toList();
  // }
}