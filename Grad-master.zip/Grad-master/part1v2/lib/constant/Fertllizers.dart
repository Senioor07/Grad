class fertllizers {
  final int fertllizersId;
  final int price;
  
  final double rating;
  final int humidity;
  final String temperature;
  final String category;
  final String fertllizersName;
  final String imageURL;

  bool isFavorated;
  final String decription;

  bool isSelected;

  fertllizers(
      {

        required this.fertllizersId,
        required this.price,
        required this.category,
        required this.fertllizersName,

        required this.rating,
        required this.humidity,
        required this.temperature,
        required this.imageURL,
        required this.isFavorated,
        required this.decription,
        required this.isSelected});

  //List of fertllizerss data
  static List<fertllizers> fertllizersList = [
    fertllizers(

        fertllizersId: 0,
        price: 22,
        category: ' even the harshest weather condition.',
        fertllizersName: 'Sanseviera',

        rating: 4.5,
        isFavorated:true,
        humidity: 34,
        temperature: '23 - 34',
        imageURL: 'assets/45.png',
        decription:
        'This fertllizers is one of the best fertllizers.It grows'
         'in most of the regions in the world and can survive'
            ,
        isSelected: false, 
         ),
    fertllizers(
      
        fertllizersId: 1,
        price: 11,
        category: 'that needs sunlight daily',
        fertllizersName: 'Perlite Zen',

         isFavorated:true,
        rating: 4.8,
        humidity: 56,
        temperature: '19 - 22',
        imageURL: 'assets/46.png',
        decription:
        'this fertllizers is very A beautiful fertllizers ',
        isSelected: false,),
    fertllizers(
        fertllizersId: 2,
        price: 18,
        category: 'and does not need to be quenched except every now and then',
        fertllizersName: 'Agri sulfur',

        rating: 4.7,
        humidity: 34,
        temperature: '22 - 25',
        imageURL: 'assets/47.png',
         isFavorated:true,
        decription:
        'Very sweet and useful. It is preferred to be inside the house ',
        isSelected: false, ),
    fertllizers(
        fertllizersId: 3,
        price: 30,
        category: 'Outdoor', ////
        fertllizersName: 'N.P.K',
      

        rating: 4.5,
        humidity: 35,
        temperature: '23 - 28',
        imageURL: 'assets/48.png',
         isFavorated:true,
        decription:
        'It is considered a sofa that brings joy and happiness.',
        isSelected: false, ),
    fertllizers(
        fertllizersId: 4,
        price: 24,
        category: 'It grows in most of the regions in the world and can survive',///
        fertllizersName: 'GoldenYe',

        rating: 4.1,
        humidity: 66,
        temperature: '12 - 16',
        imageURL: 'assets/49.png',
         isFavorated:true,
        decription:
        'This fertllizers is one of the best fertllizers.'
            ,
        isSelected: false, ),
    fertllizers(
        fertllizersId: 5,
        price: 24,
        category: 'even the harshest weather condition.',
        fertllizersName: 'Vermi Zain',
        rating: 4.4,
        humidity: 36,
        temperature: '15 - 18',
        imageURL: 'assets/50.png',
         isFavorated:true,
        decription:
        'This fertllizers grows in most of the regions in the world'
            ,
        isSelected: false,  ),
    fertllizers(
        fertllizersId: 6,
        price: 19,///
        category: 'Garden',
        fertllizersName: 'Liquid co',

        rating: 4.2,
        humidity: 46,
        temperature: '23 - 26',
        imageURL: 'assets/51.png',
         isFavorated:true,
        decription:
        'This fertllizers isthe best fertllizers'
            ,
        isSelected: false, ),
    fertllizers(
        fertllizersId: 7,
        price: 23,
        category: 'used mostly',///
        fertllizersName: 'Ismailia co',
        rating: 4.5,
        humidity: 34,
         isFavorated:true,
        temperature: '21 - 24',
        imageURL: 'assets/52.png',
        decription:
        'This fertllizers is usefull'
            ,
        isSelected: false,),
    fertllizers(
        fertllizersId: 8,
        price: 46,
        category: 'It grows in most of the regions in the world and can survive',
        fertllizersName: 'unique rose',

        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/53.png',
         isFavorated:true,
        decription:
        'This fertllizers is one of the best fertllizers.'
            ,
        isSelected: false,),
  ];

  //Get the grow items
  static List<fertllizers> getgrowfertllizerss(){
    List<fertllizers> _glList = fertllizers.fertllizersList;
    return _glList.where((element) => element.isSelected == true).toList();
  }

  // //Get the cart items
  // static List<fertllizers> addedToCartfertllizerss(){
  //   List<fertllizers> _selectedfertllizerss = fertllizers.fertllizersList;
  //   return _selectedfertllizerss.where((element) => element.isSelected == true).toList();
  // }
}