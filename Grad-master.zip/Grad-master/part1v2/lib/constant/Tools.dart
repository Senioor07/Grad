class tools {
  final int toolsId;
  final int price;
  
  final double rating;
  final int humidity;
  final String temperature;
  final String category;
  final String toolsName;
  final String imageURL;

  bool isFavorated;
  final String decription;

  bool isSelected;

  tools(
      {

        required this.toolsId,
        required this.price,
        required this.category,
        required this.toolsName,

        required this.rating,
        required this.humidity,
        required this.temperature,
        required this.imageURL,
        required this.isFavorated,
        required this.decription,
        required this.isSelected});

  //List of toolss data
  static List<tools> toolsList = [
    tools(

        toolsId: 0,
        price: 22,
        category: 'used in multiple things',
        toolsName: 'ax',

        rating: 4.5,
        isFavorated:true,
        humidity: 34,
        temperature: '23 - 34',
        imageURL: 'assets/pro42.png',
        decription:
        
            'cutting wood ,any thing ',
        isSelected: false, 
         ),
    tools(
      
        toolsId: 1,
        price: 11,
        category: 'used in land',
        toolsName: 'Axe',

         isFavorated:true,
        rating: 4.8,
        humidity: 56,
        temperature: '19 - 22',
        imageURL: 'assets/pro35.png',
        decription:
        'this tools is very important',
        isSelected: false,),
    tools(
        toolsId: 2,
        price: 18,
        category: 'Indoor',
        toolsName: 'Wide ax',

        rating: 4.7,
        humidity: 34,
        temperature: '22 - 25',
        imageURL: 'assets/pro36.png',
         isFavorated:true,
        decription:
        'Very sweet and useful. It is preferred to be inside the house and does not need to be quenched except every now and then',
        isSelected: false, ),
    tools(
        toolsId: 3,
        price: 30,
        category: 'Outdoor', ////
        toolsName: 'Broita',
      

        rating: 4.5,
        humidity: 35,
        temperature: '23 - 28',
        imageURL: 'assets/pro37.png',
         isFavorated:true,
        decription:
        'It is considered a sofa that brings joy and happiness.',
        isSelected: false, ),
    tools(
        toolsId: 4,
        price: 24,
        category: 'Flowers',///
        toolsName: 'Tr cutter',

        rating: 4.1,
        humidity: 66,
        temperature: '12 - 16',
        imageURL: 'assets/pro38.png',
         isFavorated:true,
        decription:
        'This tools is one of the best tools. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, ),
 
    tools(
        toolsId: 6,
        price: 19,///
        category: 'Garden',
        toolsName: 'fork',

        rating: 4.2,
        humidity: 46,
        temperature: '23 - 26',
        imageURL: 'assets/pro40.png',
         isFavorated:true,
        decription:
        'This tools is one of the best tools.',
        isSelected: false, ),
    tools(
        toolsId: 7,
        price: 23,
        category: 'recommended',///
        toolsName: 'Grove',
        rating: 4.5,
        humidity: 34,
         isFavorated:true,
        temperature: '21 - 24',
        imageURL: 'assets/pro41.png',
        decription:
        'This tools is used in hold things',
        isSelected: false,),
    tools(
        toolsId: 8,
        price: 46,
        category: 'cutting plants',
        toolsName: 'sickle',

        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pro43.png',
         isFavorated:true,
        decription:
        'used to cut most plants in land',
        isSelected: false,),
         tools(
        toolsId: 9,
        price: 46,
        category: 'Popular',
        toolsName: 'sided axe',

        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pro42.png',

         isFavorated:true,
        decription:
        'This tools is one of the best tools. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,  ),
  ];

  //Get the grow items
  static List<tools> getgrowtoolss(){
    List<tools> _glList = tools.toolsList;
    return _glList.where((element) => element.isSelected == true).toList();
  }

  // //Get the cart items
  // static List<tools> addedToCarttoolss(){
  //   List<tools> _selectedtoolss = tools.toolsList;
  //   return _selectedtoolss.where((element) => element.isSelected == true).toList();
  // }
}