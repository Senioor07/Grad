class Plant {
  final int plantId;
  final int price;
  
  final double rating;
  final int humidity;
  final String temperature;
  final String category;
  final String plantName;
  final String plantName2;
  final String plantNameseeds;
  final String imageURL;
  final String imageURL2;
  final String imageURLseeds;
  bool isFavorated;
  final String decription;
  final String decription2;
  bool isSelected;

  Plant(
      {
       required this.plantName2,
        required this.decription2,
        required this.plantId,
        required this.price,
        required this.category,
        required this.plantName,
        required this.plantNameseeds,
        required this.rating,
        required this.humidity,
        required this.temperature,
        required this.imageURL,
        required this.imageURL2,
        required this.imageURLseeds,
        required this.isFavorated,
        required this.decription,
        required this.isSelected});

  //List of Plants data
  static List<Plant> plantList = [
    Plant(

        plantId: 0,
        price: 22,
        category: 'Indoor',
        plantName: 'Sanseviera',
        plantName2: 'seviera',
        decription2: 'growing at : 7 days'
        ,
        rating: 4.5,
        isFavorated:true,
        humidity: 34,
        temperature: '23 - 34',
        imageURL: 'assets/pic26.png',
         imageURL2: 'assets/pro3.png',
        decription:
        'This plant is one of the best plant.It grows'
         'in most of the regions in the world and can survive'
            ' even the harshest weather condition.',
        isSelected: false, 
        plantNameseeds: "it need to have the power frm sun daily",
        imageURLseeds: ''
         ),
    Plant(
      
        plantId: 1,
        price: 11,
        category: 'Outdoor',
        plantName: 'green flowers',
         plantName2: 'green flow',
        decription2:'growing at : 4 days',
         isFavorated:true,
        rating: 4.8,
        humidity: 56,
        temperature: '19 - 22',
        imageURL: 'assets/pic27.png',
         imageURL2: 'assets/pro4.png',
        decription:
        'this plant is very A beautiful plant that needs sunlight daily',
        isSelected: false, 
        plantNameseeds: "it need to have the power frm sun daily",
         imageURLseeds: ''),
    Plant(
        plantId: 2,
        price: 18,
        category: 'Indoor',
        plantName: 'Beach Daisy',
        plantName2: 'Daisy',
        decription2: 'growing at : 7 days',
        rating: 4.7,
        humidity: 34,
        temperature: '22 - 25',
        imageURL: 'assets/pic23.png',
        imageURL2: 'assets/pro5.png',
        imageURLseeds:"",
         isFavorated:true,
        decription:
        'Very sweet and useful. It is preferred to be inside the house and does not need to be quenched except every now and then',
        isSelected: false,
         plantNameseeds: "it need to have the power frm sun daily",),
    Plant(
        plantId: 3,
        price: 30,
        category: 'Outdoor', ////
        plantName: 'Potted Gerbera',
        plantName2: 'Potted ',
        decription2: 'growing at : 4 days',
        rating: 4.5,
        humidity: 35,
        temperature: '23 - 28',
        imageURL: 'assets/pic25.png',
        imageURL2: 'assets/pro6.png',
         isFavorated:true,
        decription:
        'It is considered a sofa that brings joy and happiness.',
        isSelected: false,
         plantNameseeds:  "it need to have the power frm sun daily",
          imageURLseeds: ''),
    Plant(
        plantId: 4,
        price: 24,
        category: 'Flowers',///
        plantName: 'Golden Y',
        plantName2: 'Golden R',
        decription2: 'growing at : 8 days',
        rating: 4.1,
        humidity: 66,
        temperature: '12 - 16',
        imageURL: 'assets/pic38.png',
        imageURL2: 'assets/pro7.png',
         isFavorated:true,
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, 
        plantNameseeds:  "it need to have the power frm sun daily", 
        imageURLseeds: ''),
    Plant(
        plantId: 5,
        price: 24,
        category: 'Popular',
        plantName: 'Meadow',
         plantName2: 'Sage',
        decription2: 'growing at : 3 days',
        rating: 4.4,
        humidity: 36,
        temperature: '15 - 18',
        imageURL: 'assets/pic28.png',
        imageURL2: 'assets/pro8.png',
         isFavorated:true,
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, plantNameseeds:  "it need have the power frm sun daily",
         imageURLseeds: ''),
    Plant(
        plantId: 6,
        price: 19,///
        category: 'Garden',
        plantName: 'yell yasmi',
      plantName2: 'Red yasmi',
        decription2: 'growing at : 9 days',
        rating: 4.2,
        humidity: 46,
        temperature: '23 - 26',
        imageURL: 'assets/pic34.png',
        imageURL2: 'assets/pro9.png',
         isFavorated:true,
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,
         imageURLseeds: '', 
         plantNameseeds:  "it need to have the power frm sun daily"),
    Plant(
        plantId: 7,
        price: 23,
        category: 'recommended',///
        plantName: 'Tritonia',
         plantName2: 'Trit',
        decription2: 'growing at : 5 days',
        rating: 4.5,
        humidity: 34,
         isFavorated:true,
        temperature: '21 - 24',
        imageURL: 'assets/pic37.png',
        imageURL2: 'assets/pro10.png',
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,
         plantNameseeds:  "it need to have the power frm sun daily", 
         imageURLseeds: ''),
    Plant(
        plantId: 8,
        price: 46,
        category: 'Flowers',
        plantName: 'uni rose',
         plantName2: 'Rose',
        decription2: 'growing at : 4 days',
        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pic21.jpg',
        imageURL2: 'assets/pro11.png',
         isFavorated:true,
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false, 
        plantNameseeds:  "it need to have the power frm sun daily",
         imageURLseeds: ''),
         Plant(
        plantId: 9,
        price: 46,
        category: 'Popular',
        plantName: 'adlit',
         plantName2: 'Cgjol',
        decription2: 'growing at : 2 days',
        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pic32.png',
        imageURL2: 'assets/pro12.png',
         isFavorated:true,
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,
         plantNameseeds:  "it need to have the power frm sun daily", 
         imageURLseeds: ''),
         Plant(
        plantId: 9,
        price: 46,
        category: 'saouse',
        plantName: 'kmnouh',
         plantName2: 'Kalop',
          isFavorated:true,
        decription2: '',
        rating: 4.7,
        humidity: 46,
        temperature: '21 - 25',
        imageURL: 'assets/pic36.png',
        imageURL2: 'assets/pro13.png',
        decription:
        'This plant is one of the best plant. It grows in most of the regions in the world and can survive'
            'even the harshest weather condition.',
        isSelected: false,
         plantNameseeds:  "it need to have the power frm sun daily",
          imageURLseeds: ''),
  ];

  //Get the grow items
  static List<Plant> getgrowPlants(){
    List<Plant> _glList = Plant.plantList;
    return _glList.where((element) => element.isSelected == true).toList();
  }

  // //Get the cart items
  // static List<Plant> addedToCartPlants(){
  //   List<Plant> _selectedPlants = Plant.plantList;
  //   return _selectedPlants.where((element) => element.isSelected == true).toList();
  // }
}