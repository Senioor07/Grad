class WE {
  
final int wtId;
  final String temday;
  final String temhour;
  final String imagehour;
  final String imageday;
  final String hour;
  final String day;
  final String describ;



  WE(
      {
       required this.wtId,
       required this.describ,
        required this.temday,
        required this.temhour,
        required this.imageday,
        required this.imagehour,
        required this.day,
        required this.hour,

        });

  //List of Plants data
  static List<WE> WetList = [
   WE(

        wtId: 0,
        temday: '27/14 ºC',
        imageday: 'assets/df2.png',
        day: 'sun,Des 03',
        imagehour: 'assets/dl1.png',
        hour: '6:00',
        temhour: '25 ºC', describ: 'party cloud',
        
         ),
         WE(

        wtId: 1,
        temday: '27/15 ºC',
        imageday: 'assets/df.png',
        day: 'Mon,Des 04',
        imagehour: 'assets/dl2.png',
        hour: '7:00',
         temhour: '22 ºC',
        describ: 'clear sky'
         ),
         WE(

        wtId: 2,
        temday: '26/15 ºC',
        imageday: 'assets/sun.png',
        day: 'Tue,Des 05',
        imagehour: 'assets/dl3.png',
        hour: '8:00',
         temhour: '18 ºC',
        describ: 'clear sky'
         ),
         WE(

        wtId: 3,
        temday: '23/13 ºC',
        imageday: 'assets/df3.png',
        day: 'Wed,Des 06',
        imagehour: 'assets/dl4.png',
        hour: '9:00',
         temhour: '17 ºC',
        describ: 'overcast clouds'
         ),
         WE(

        wtId: 4,
        temday: '23/14 ºC',
        imageday: 'assets/storm.png',
        day: 'Thu,Des 07',
        imagehour: 'assets/dl5.png',
        hour: '10:00',
         temhour: '13 ºC',
        describ: 'overcast clouds'
         ),
        WE(

        wtId: 5,
        temday: '23/13 ºC',
        imageday: 'assets/cloudimage.png',
        day: 'Fri,Des 08',
        imagehour: 'assets/dl6.png',
        hour: '11:00',
         temhour: '16 ºC',
        describ: 'few clouds'
         ),
         WE(

        wtId: 6,
        temday: '23/13 ºC',
        imageday: 'assets/cloudimage2.png',
        day: 'sat,Des 09',
        imagehour: 'assets/dl7.png',
        hour: '12:00',
         temhour: '15 ºC',
        describ: 'few clouds'
         ),
         
   
  ];

 

}
