import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:part1v2/screen/Shipping.dart';

class bottomnaviCard extends StatelessWidget {
  const bottomnaviCard({super.key});

  @override
  Widget build(BuildContext context) {
    return BottomAppBar(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 7.w),
        height: 150.h,
        child: Row(
          children: [
            Row(
              children: [
                Text("Total :",style: TextStyle(
                  fontSize: 19,fontWeight: FontWeight.w500,
                  color: Colors.black
                ),),
                SizedBox(width: 15.w,),
                Text("320\$",style: TextStyle(
                  fontSize: 19,fontWeight: FontWeight.w500,color: Color.fromARGB(255, 181, 77, 77)
                ),),

              ],
            ),
            SizedBox(width: 60.w,),
            ElevatedButton(onPressed: (){
              Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Shipping()));
            },
            style: ButtonStyle(
            
              backgroundColor: MaterialStateProperty.all<Color>(Color.fromARGB(255, 84, 206, 88),),
              padding: MaterialStateProperty.all(
                EdgeInsets.symmetric(vertical: 13.h,horizontal: 15.w),

              ),
              shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))
              )
            ),
             child: Text("Order Now",style: TextStyle(fontSize: 20,color: Color.fromARGB(255, 116, 48, 36)),))
          ],
        ),
        
      ),


    );
  }
}