import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

String selectedLanguage = 'English';
class drawerVendor extends StatefulWidget {
  
  const drawerVendor({super.key});

  @override
  State<drawerVendor> createState() => _drawerVendorState();
}

class _drawerVendorState extends State<drawerVendor> {
  @override
  Widget build(BuildContext context) {
    
    return Container(
      width: 230,
      child: Drawer(
        backgroundColor: Color.fromARGB(255, 244, 242, 242),
        child: Column(
          children: [
            DrawerHeader(child: 
             Stack(
                    children: [
                      Container(width: 116,height: 115,
                      decoration: BoxDecoration(
                        border: Border.all(
                          width: 4,
                          color: Theme.of(context).scaffoldBackgroundColor,
                        ),
                        boxShadow:[ BoxShadow(
                          spreadRadius: 2,blurRadius: 10,
                          color: Colors.black.withOpacity(.1),
                          offset: Offset(0, 10)
                        ),],
                        shape: BoxShape.circle,
                        image: DecorationImage(image:
                         AssetImage('assets/profile.jpg'),fit:BoxFit.cover)
                      ),),
                       Positioned(
                            bottom: 0,
                            right: 0,
                            top: 45,
                            child: Container(
                              height: 40,
                              width: 40,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(
                                  width: 4,
                                  color: Theme.of(context).scaffoldBackgroundColor,
                                ),
                                color: Color.fromARGB(255, 111, 30, 8),
                              ),
                              child: Icon(
                                Icons.camera_alt_rounded,
                                color: Colors.white,
                              ),
                            )),
                    ],
                  ),
            
            
            
            ),
            // Padding(
              
            //   padding: const EdgeInsets.only(left:10.0),
            //   child: ListTile(
            //   //   leading: Icon(Icons.home_filled,color: Color.fromRGBO(122, 61, 59, 1),),
            //   //   onTap: (){
            //   //     // Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>homePage()));
            //   //   },
            //   //   title: 
            //   // Text('HOME',style:TextStyle(fontSize:25),),
            //   ),
    
            // ),
             Padding(
               padding: const EdgeInsets.only(left: 10),
               child: GestureDetector(
                  onTap: (){
                  
                  },
                  child: Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.all(Radius.circular(10)),
                   // color: Color.fromRGBO(229, 226, 226, 0.708)
                  ),
                  height: 50,
                     child: Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Padding(
                         padding: const EdgeInsets.all(8.0),
                         child: Text(
                'Language',
                style: TextStyle(fontSize: 15,fontWeight: FontWeight.bold),
                         ),
                       ),
                       DropdownButton<String>(
                         value: selectedLanguage,
                         icon: Icon(Icons.keyboard_arrow_down_rounded, size: 40),
                         onChanged: 
                         ( newValue) {
                setState(() {
                  selectedLanguage = newValue!;
                });
                         },
                         items: <String>['English', 'Arabic'] // available language
                  .map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
                         }).toList(),
                       ),
                     ],
                   ),
                    
                    ),
                ),
             ),
             SizedBox(height: 20,),
            Padding(
              padding: const EdgeInsets.only(left: 10),
              child: Row(children:
               [Icon(Icons.volume_up_outlined,color: Color.fromARGB(184, 46, 85, 25),),
               Text('Notification',style: 
               TextStyle(fontSize: 17,fontWeight: FontWeight.w800),)
               ],
               ),
            ),
             SizedBox(height: 15,),
             Divider(height: 8,thickness: 2,),
             SizedBox(height: 15,),
             Padding(
               padding: const EdgeInsets.only(left: 10),
               child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children:[
                  Text('New for you',style: TextStyle(fontSize: 17,fontWeight: FontWeight.w800),),
                  Transform.scale(scale: 0.7,
                  child: CupertinoSwitch(
                    value: true,
                     onChanged: (bool val){},),
                  )
                ]
               ),
             ),
               
              
              
          ],
        ),
      ),
    );
  }
}