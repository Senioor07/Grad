import 'package:flutter/material.dart';
import 'package:part1v2/screen/fertllizersmarket.dart';
import 'package:part1v2/screen/plantmarket.dart';
import 'package:part1v2/screen/seedsmarket.dart';
import 'package:part1v2/screen/toolsmarket.dart';

class TabBarWidget extends StatefulWidget {
  

  @override
  _TabBarWidgetState createState() => _TabBarWidgetState();
}

class _TabBarWidgetState extends State<TabBarWidget> with TickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            child: Align(
              alignment: Alignment.centerLeft,
              child: TabBar(
                labelColor: Colors.black,
                isScrollable: true,
                labelPadding: EdgeInsets.only(left: 30, right: 30),
                indicatorColor:  Color.fromARGB(255, 72, 160, 67),
                unselectedLabelColor: const Color.fromARGB(255, 100, 98, 98),
                controller: _tabController,
                tabs: [
                  Tab(text: "Plants"),
                  Tab(text: "Fertiliz"),
                  Tab(text: "Seeds"),
                  Tab(text: "Tools"),
                ],
              ),
            ),
          ),
          Container(
            height: 800,
            child: TabBarView(
              controller: _tabController,
              children: [
             plantmarket(),
             fertllizersmarket(),
             seedsmarket(),
             toolsmarket()
              ],
            ),
          ),
        ],
      ),
    );
  }
}